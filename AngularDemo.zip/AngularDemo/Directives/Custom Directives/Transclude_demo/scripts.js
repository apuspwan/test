var app = angular.module('myApp', []);

app.controller('mainController', function($scope) {
    $scope.name = 'World';
    $scope.hobby = 'AngularJS';
    
    $scope.items=[1,5,3,6,9];
});

//Inserts the contents inside the div tag, because div tag contains the ng-transclude attr
app.directive('outputText', function() {
    return {
        transclude: true,
        scope: {},
        template: '<div class="directive-container" ng-transclude></div>'
    }
});

//include the contents inside the <p> tag because <p> tag contains ng-transclude
//whatever content is already inside the <p> will be replaced with the transcluded content
app.directive('sampleText', function() {
    return {
        transclude: true,
        scope: {},
        template: '<div class="directive-container"><p ng-transclude>This will be replaced</p></div>'
    }
});