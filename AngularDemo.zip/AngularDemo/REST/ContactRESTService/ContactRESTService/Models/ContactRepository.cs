﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RESTServices.Models
{
     public class ContactRepository
     {
          public List<Contact> contacts = new List<Contact>()
          {
               new Contact() { Id=101, FirstName="Sankar", LastName="Ram", Email="sankar@gmail.com", Mobile="9685741425", Fax="0224578584" },
               new Contact() { Id=102, FirstName="Praveen", LastName="Kumar", Email="praveenk@gmail.com", Mobile="9656325147", Fax="02145785452" },
               new Contact() { Id=103, FirstName="Ajay", LastName="Kumar", Email="ajaykumar@gmail.com", Mobile="8675458694", Fax="02245786958" },
               new Contact() { Id=104, FirstName="Meghna", LastName="Naidu", Email="meghnanaidu@gmail.com", Mobile="8574961245", Fax="021457855365" },
               new Contact() { Id=105, FirstName="Gagan", LastName="Ajit", Email="gagan_001@gmail.com", Mobile="8475958615", Fax="02236251478" }
          };
       
          public bool Add(Contact contact)
          {
               var id = contacts.Max(m => m.Id) +1;
               contact.Id = id;
               contacts.Add(contact);
               return true;
          }

          public bool Delete(int id)
          {
               var temp = contacts.SingleOrDefault(s => s.Id == id);
               if(temp!=null)
               {
                    contacts.Remove(temp);
                    return true;
               }
               else
               {
                    return false;
               }
          }
          public bool Update(Contact contact)
          {
               var c = contacts.SingleOrDefault(s => s.Id == contact.Id);
               if(c!=null)
               {
                    c.FirstName = contact.FirstName;
                    c.LastName = contact.LastName;
                    c.Mobile = contact.Mobile;
                    c.Fax = contact.Fax;
                    c.Email = contact.Email;
                    return true;
               }
               else
               {
                    return false;
               }
          }

          public List<Contact> GetAll()
          {
               return contacts;
          }

          public Contact GetById(int id)
          {
               return contacts.SingleOrDefault(s => s.Id == id);
          }
     }
}