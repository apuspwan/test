﻿using RESTServices.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace RESTServices
{

	[ServiceContract]
	public interface IContactService
	{
		[OperationContract]
		[WebGet(ResponseFormat=WebMessageFormat.Json, UriTemplate="Contacts/")]
		//[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, UriTemplate = "Contacts/")]
		IEnumerable<Contact> GetContacts();

		[OperationContract]
		[WebGet(ResponseFormat = WebMessageFormat.Json, UriTemplate = "Contacts/{id}")]
		//[WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, UriTemplate = "Contacts/{id}")]
		Contact GetContact(string id);

		[OperationContract]
		[WebInvoke(Method = "POST", 
				ResponseFormat = WebMessageFormat.Json, 
				RequestFormat =WebMessageFormat.Json,
				UriTemplate= "AddContact", 
				BodyStyle=WebMessageBodyStyle.Wrapped)]
		bool AddContact(Contact contact);

		[OperationContract]
		[WebInvoke(Method = "PUT", ResponseFormat = WebMessageFormat.Json,
			UriTemplate = "UpdateContact/{id}", BodyStyle = WebMessageBodyStyle.Wrapped)]
		bool UpdateContact(Contact contact, string id);

		[OperationContract]
		[WebInvoke(Method = "DELETE", ResponseFormat = WebMessageFormat.Json,
			UriTemplate = "DeleteContact/{id}")]
		bool DeleteContact(string id);

	}
}
