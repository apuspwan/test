﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using RESTServices.Models;
using System.ServiceModel.Activation;


namespace RESTServices
{
	[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
	[ServiceBehavior(Namespace ="ContactServiceNS")]
	public class ContactService : IContactService
	{
          static ContactRepository repo = new ContactRepository();
		public IEnumerable<Contact> GetContacts()
		{
               return repo.GetAll();
		}

		public Contact GetContact(string id)
		{
               return repo.GetById(Convert.ToInt32(id));
		}

		public bool AddContact(Contact contact)
		{
               return repo.Add(contact);
		}

		public bool UpdateContact(Contact contact, string id)
		{
               return repo.Update(contact);
		}

		public bool DeleteContact(string id)
		{
               return repo.Delete(Convert.ToInt32(id));
		}
	}
}
