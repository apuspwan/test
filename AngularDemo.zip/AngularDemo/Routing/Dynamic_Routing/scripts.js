var app=angular.module('myApp',['ngRoute']);

app.run(function ($rootScope) {
    $rootScope.$on('$routeChangeSuccess', function (e, current, pre) {
        console.log(current.$$route.url);
    });
});

app.config(function($routeProvider, $locationProvider){
     $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });
    
    $routeProvider
    .when('/',{
        templateUrl:'pages/home.html',
        controller:'pageController'
    })    
    .when('/page/:pagename*',{
        templateUrl:function(urlattr){
           return '/pages/' + urlattr.pagename+'.html';
        },
        controller:'pageController'
    })
    .otherwise({
        redirectTo:'/'
    });
    /*Adding * let you work with multiple levels of directories dynamically. 
    Example: /page/cars/selling/list will be catch on this provider
    */
});

app.controller('mainController',function($scope){
    
});

app.controller('pageController',function($scope){
    $scope.Message='Hai';
})

