var app = angular.module("myApp", ['ngRoute']);

app.run(['$rootScope', '$location', function ($rootScope, $location) {

    $rootScope.$on('$routeChangeStart', function (event) {
        var allowedPages=['/login','/home','/'];
        var isRestrictedPage=allowedPages.indexOf($location.path())===-1;
        console.log('Requested page:' + $location.path());
        if (isRestrictedPage)
        {
            console.log('Accessing restricted page:' + $rootScope.loggedIn);
            if(angular.isUndefined($rootScope.loggedIn) ||  !$rootScope.loggedIn) {
                console.log('DENY');
                event.preventDefault();
                $location.path('#/login');
            }
        }
    });
}]);

app.config(function ($routeProvider,$locationProvider) {
    
    
    $routeProvider
        .when('/',{
            templateUrl:'home.html',
            controller:'homeCtrl'
        })
        .when('/login', {
            templateUrl:'login.html',
            controller:'loginCtrl'
        })
        .when('/home',{
            templateUrl:'home.html',
            controller:'homeCtrl'
        })
        .when('/dashboard', { 
            templateUrl:'dashboard.html' ,
            controller:'dashboardCtrl'
        })
        .otherwise({
            redirectTo:'/'
        });
});

app.controller('loginCtrl',['$scope','$location','$rootScope',function($scope,$location,$rootScope){
    $scope.login=function(){
        
        if($scope.username=='admin' && $scope.password=='admin'){
            $rootScope.loggedIn=true;
            console.log('Logged in');
            $location.hash('#/dashboard');
        }else {
            console.log('invalid username and password');
            $location.path('#/');
        }
    };
    
}]);
app.controller('homeCtrl',['$scope',function(){

}]);

app.controller('dashboardCtrl',['$scope',function(){

}]);