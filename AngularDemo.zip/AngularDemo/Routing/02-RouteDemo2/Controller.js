var app=angular.module("mainApp",["ngRoute"]);

app.config(function($routeProvider){
   $routeProvider
   .when('/',{
       templateUrl:'home.html',
       //controller:'homeController'
   })
   .when('/about',{
       templateUrl:'about.html',
       //controller:'AboutController'
   })
   .when('/contact',{
       templateUrl:'contact.html'
   })
   .otherwise({
       redirectTo:'/'
   })
});

