var app=angular.module('mainApp',['ngRoute']);
app.config(function($routeProvider){
    $routeProvider
    .when('/',{
        template:'Welcome User'
    }).when('/guest',{
        template:'Welcome guest'
    }).otherwise({
        redirectTo:'/'
    });
});