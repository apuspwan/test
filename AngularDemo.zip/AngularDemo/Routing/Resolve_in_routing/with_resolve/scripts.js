var app=angular.module('myApp',['ngRoute']);

app.config(function($routeProvider, $locationProvider){
    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });
    
    $routeProvider
    .when('/',{
        templateUrl:'pages/home.html'
    })
    .when('/about',{
        templateUrl:'pages/about.html'
    })
    .when('/contact',{
        templateUrl:'pages/contact.html'
    })
    .when('/products',{
        templateUrl:'pages/list_view.html',
        controller:'productController',
        resolve:{
            "productService":function($q, $http, $timeout){
                var svc=$q.defer();
                $timeout(function(){
                    svc.resolve({
                        getProducts:function(scope){
                            $http.get('products.json')
                            .success(function(resp){
                                console.log(JSON.stringify(resp));
                                scope.products=resp;
                                return "empty";
                            })
                            .error(function(resp,num,status){
                                console.log("Error:" + resp + "," + num + "," + status);
                                return "error";
                            })
                        }  
                    })                    
                },5000);
                return svc.promise;
            }      
        }
    })
    .otherwise({
        redirectTo:'/'
    });
});

app.controller('mainController',function($scope){
    
});

app.controller('productController',function($scope,productService){
    $scope.products=productService.getProducts($scope);
});