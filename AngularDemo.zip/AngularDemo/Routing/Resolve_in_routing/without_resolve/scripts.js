var app=angular.module('myApp',['ngRoute']);

app.config(function($routeProvider, $locationProvider){
    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });
    
    $routeProvider
    .when('/',{
        templateUrl:'pages/home.html'
    })
    .when('/about',{
        templateUrl:'pages/about.html'
    })
    .when('/contact',{
        templateUrl:'pages/contact.html'
    })
    .when('/products',{
        templateUrl:'pages/list_view.html',
        controller:'productController',
        
    })
    .otherwise({
        redirectTo:'/'
    })
});

app.factory( "productService", function( $http,$timeout ) {
    return {
        getProducts: function( scope ) {
            $timeout(function(){
                $http.get('products.json')
                .success(function(response){
                    console.log(JSON.stringify(response));
                    scope.products=response;
                })
                .error(function(resp,num,status){
                    console.log('error:' + resp + "," + num + "," + status)
                })
                
            },5000);            
            return "empty";
        }
    }
} );

app.controller('mainController',function($scope){
    
});

app.controller('productController',function($scope,productService){
    $scope.products=productService.getProducts($scope);
})