var app=angular.module('myApp',['ngRoute']);

app.config(function($routeProvider, $locationProvider){
    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });
    
    $routeProvider
    .when('/',{
        templateUrl:'pages/home.html'
    })
    .when('/about',{
        templateUrl:'pages/about.html'
    })
    .when('/contact',{
        templateUrl:'pages/contact.html'
    })
    .when('/products',{
        templateUrl:'pages/list_view.html',
        controller:'productController',
        resolve:{
            productService:function($q,$http,$timeout) {
                var defer = $q.defer();
                $timeout(function(){
                    $http.get('products.json')
                    .success(function(resp){
                        console.log("Data=" + JSON.stringify(resp));
                        defer.resolve(resp);
                    })
                    .error(function(resp,num,status){
                        console.log("Error:" + resp + "," + num + "," + status);
                        defer.reject("error");
                    })
                },3000);    
                return defer.promise;
            }
        }
    })
    .otherwise({
        redirectTo:'/'
    });
});

app.controller('mainController',function($scope){
    
});


app.controller('productController', ['$scope', '$location', 'productService', function ($scope, $location, productService) {

  $scope.products = productService;
}]);
