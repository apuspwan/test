// Step 1:  Add Product Module
var productModule = angular.module("productModule", ["ngRoute"]);


productModule.config(function ($routeProvider, $locationProvider) {
    $locationProvider.html5Mode(true);
    $routeProvider.when("/edit/:id", {
        templateUrl: "/editView.html",
        controller: "productController"
    });
    $routeProvider.when("/create", {
        templateUrl: "/editView.html",
        controller: "productController"
    });
    $routeProvider.otherwise({
        templateUrl: "/index.html"
    });
});

// Step 2: Add Product Controller
productModule.controller("productController", function ($scope,$location) {

    // Step 3: Set Display mode  to "list" as we need to switch between 2 views
    $scope.displayMode = "list";
    $scope.currentProduct = null;

    // Step 4: Create a function that display list of Products

    $scope.listProducts = function () {

        $scope.products = [
            { id: 0, name: "Apple", category: "fruit", price: 8888 },

            { id: 1, name: "Rin", category: "Detergent", price: 83131 },

            { id: 2, name: "Mobile", category: "Gadget", price: 6313 }
        ];

    }

    // Step5: Create Delete Product function which will delete the selected product.
    $scope.deleteProduct = function (product) {

        $scope.products.splice($scope.products.indexOf(product), 1);
    }

    //Step 6 : Create Product functionality
    $scope.createProduct = function (product) {

        $scope.products.push(product);
        $scope.displayMode = "list";
        $location.path("/list");
    }

    // Step 7. Update Product functionality
    $scope.updateProduct = function (product) {

        for (var i = 0; i < $scope.products.length; i++) {
            if ($scope.products[i].id == product.id) {
                $scope.products[i] = product;
                break;

            }

        }
        // $scope.displayMode = "list";
        $location.path("/list");
    }


    //Stpe 8 :Call EditorCreateProduct functioanluty on save button click

    $scope.editOrCreateProduct = function (product) {

        $scope.currentProduct = product ? angular.copy(product) : {};
         $scope.displayMode = "edit";
        $location.path("/edit");
    }

    $scope.saveEdit = function (product) {
        if (angular.isDefined(product.id)) {

            alert('Update Product');
            $scope.updateProduct(product);

        }
        else {
            alert('Create Product');
            $scope.createProduct(product);
        }
    }

    $scope.cancelEdit=function()
    {
        $scope.currentProduct = {};
        $scope.displayMode = "list";
        $location.path("/list");
    }
    $scope.listProducts();
});