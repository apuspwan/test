﻿var myDemoApp = angular.module('myApp', ['ngRoute']);

myDemoApp.config(function ($routeProvider) {
    $routeProvider
    .when('/view1',
    {
        controller: 'simpleController',
        templateUrl: 'view1.html'
    })
    .when('/view2',
    {
        controller: 'simpleController',
        templateUrl: 'view2.html'
    })
    .otherwise({ redirectTo: '/view1' });
});

myDemoApp.controller('simpleController', function ($scope) {
    $scope.customers = [
    { name: 'John Smith ', city: 'LosAngeles' },
    { name: 'John Doe ', city: 'NewYork' },
    { name: 'Jane Doe ', city: 'SanFrancisco' }];

});