
var module=angular.module('myApp',['ngRoute']);

module.config(['$routeProvider','$locationProvider',function($routeProvider,$locationProvider){
        
    $routeProvider
    .when('/',{
        templateUrl:'pages/home.html',
        controller:'homeController'
    })
    .when('/products',{
        templateUrl:'pages/products.html',
        controller:'productController'
    })
    .when('/products/:id',{
        templateUrl:'pages/details.html',
        controller:'detailController'
    })
    .when('/services',{
        templateUrl:'pages/services.html',
        controller:'serviceController'
    })
    .otherwise({
        redirectTo:'/'
    })
        
    $locationProvider.html5Mode({
        enabled: true,
        requireBase: false
    });

}]);

module.controller("mainController",['$scope',function($scope){
    
}]);

module.controller("homeController",['$scope',function($scope){
    $scope.Message="This is Home page";
}]);

module.controller("productController",['$scope',function($scope){
    $scope.Message="This is product page";
    $scope.Products=[
        {Id:101, Name:'Apple', Price:145.50},
        {Id:102, Name:'Orange', Price:60.00},
        {Id:103, Name:'Grape', Price:125.00}
    ];
}]);

module.controller("serviceController",['$scope',function($scope){
    $scope.Message="This is Service page";
}]);

module.controller("detailController", ['$scope','$routeParams',function($scope, $routeParams) {
    $scope.Id = $routeParams.id;
    
}]);