﻿namespace DataValidationTool
{
    partial class Connection_Template
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Connection_Template));
            this.lblAdd = new System.Windows.Forms.Label();
            this.btnTest = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.uC_SQL1 = new DataValidationTool.UC.UC_SQL();
            this.uC_Netezza1 = new DataValidationTool.UC.UC_Netezza();
            this.uC_TeraOrac1 = new DataValidationTool.UC.UC_TeraOrac();
            this.uC_File1 = new DataValidationTool.UC.UC_File();
            this.uC_Oracle1 = new DataValidationTool.UC_Oracle();
            this.SuspendLayout();
            // 
            // lblAdd
            // 
            this.lblAdd.AutoSize = true;
            this.lblAdd.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold);
            this.lblAdd.ForeColor = System.Drawing.Color.Purple;
            this.lblAdd.Location = new System.Drawing.Point(12, 21);
            this.lblAdd.Name = "lblAdd";
            this.lblAdd.Size = new System.Drawing.Size(0, 17);
            this.lblAdd.TabIndex = 9;
            // 
            // btnTest
            // 
            this.btnTest.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnTest.FlatAppearance.BorderColor = System.Drawing.Color.Purple;
            this.btnTest.FlatAppearance.BorderSize = 6;
            this.btnTest.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTest.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTest.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnTest.Location = new System.Drawing.Point(15, 283);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(131, 23);
            this.btnTest.TabIndex = 11;
            this.btnTest.Text = "Test Connection";
            this.btnTest.UseVisualStyleBackColor = false;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Purple;
            this.btnSave.FlatAppearance.BorderSize = 6;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSave.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnSave.Location = new System.Drawing.Point(365, 283);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(74, 23);
            this.btnSave.TabIndex = 12;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClose.FlatAppearance.BorderColor = System.Drawing.Color.Purple;
            this.btnClose.FlatAppearance.BorderSize = 6;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClose.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnClose.Location = new System.Drawing.Point(448, 283);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(74, 23);
            this.btnClose.TabIndex = 13;
            this.btnClose.Text = "Previous";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnExit
            // 
            this.btnExit.AutoEllipsis = true;
            this.btnExit.BackColor = System.Drawing.Color.Wheat;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatAppearance.BorderSize = 6;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.DarkRed;
            this.btnExit.Location = new System.Drawing.Point(453, 1);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 18;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // uC_SQL1
            // 
            this.uC_SQL1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uC_SQL1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uC_SQL1.Location = new System.Drawing.Point(15, 42);
            this.uC_SQL1.Name = "uC_SQL1";
            this.uC_SQL1.Size = new System.Drawing.Size(501, 212);
            this.uC_SQL1.TabIndex = 17;
            this.uC_SQL1.Visible = false;
            // 
            // uC_Netezza1
            // 
            this.uC_Netezza1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uC_Netezza1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uC_Netezza1.Location = new System.Drawing.Point(12, 42);
            this.uC_Netezza1.Name = "uC_Netezza1";
            this.uC_Netezza1.Size = new System.Drawing.Size(501, 203);
            this.uC_Netezza1.TabIndex = 16;
            this.uC_Netezza1.Visible = false;
            // 
            // uC_TeraOrac1
            // 
            this.uC_TeraOrac1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uC_TeraOrac1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uC_TeraOrac1.Location = new System.Drawing.Point(15, 41);
            this.uC_TeraOrac1.Name = "uC_TeraOrac1";
            this.uC_TeraOrac1.Size = new System.Drawing.Size(501, 204);
            this.uC_TeraOrac1.TabIndex = 15;
            this.uC_TeraOrac1.Visible = false;
            // 
            // uC_File1
            // 
            this.uC_File1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uC_File1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uC_File1.Location = new System.Drawing.Point(15, 41);
            this.uC_File1.Name = "uC_File1";
            this.uC_File1.Size = new System.Drawing.Size(482, 179);
            this.uC_File1.TabIndex = 14;
            this.uC_File1.Visible = false;
            // 
            // uC_Oracle1
            // 
            this.uC_Oracle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uC_Oracle1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uC_Oracle1.Location = new System.Drawing.Point(12, 41);
            this.uC_Oracle1.Name = "uC_Oracle1";
            this.uC_Oracle1.Size = new System.Drawing.Size(504, 179);
            this.uC_Oracle1.TabIndex = 10;
            this.uC_Oracle1.Visible = false;
            // 
            // Connection_Template
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.BackgroundImage = global::DataValidationTool.Properties.Resources.CAP22;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(534, 318);
            this.ControlBox = false;
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.uC_SQL1);
            this.Controls.Add(this.uC_Netezza1);
            this.Controls.Add(this.uC_TeraOrac1);
            this.Controls.Add(this.uC_File1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.uC_Oracle1);
            this.Controls.Add(this.lblAdd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Connection_Template";
            this.Text = "One Click";
            this.Load += new System.EventHandler(this.Connection_Template_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAdd;
        private UC_Oracle uC_Oracle1;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnClose;
        private UC.UC_File uC_File1;
        private UC.UC_TeraOrac uC_TeraOrac1;
        private UC.UC_Netezza uC_Netezza1;
        private UC.UC_SQL uC_SQL1;
        private System.Windows.Forms.Button btnExit;

    }
}