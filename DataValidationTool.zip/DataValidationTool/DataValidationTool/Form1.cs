﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ConnectionDBFactory;

namespace DataValidationTool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {




        }

        private void button1_Click(object sender, EventArgs e)
        {
            int T1 =18;
            int T2=88;
            int RowCount=0;
            RowCount = BAL.GreaterRows(T1, T2);

            MessageBox.Show(RowCount.ToString());

        }
    }
}
