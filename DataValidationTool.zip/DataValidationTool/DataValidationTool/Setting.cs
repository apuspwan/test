﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectionDBFactory;

namespace DataValidationTool
{
    public partial class Setting : Form
    {
        public Setting()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            DataManager dbManager = null;
            string SQL = string.Empty;
            string Constr = @"Data Source=C:\DB\ETL.sdf";
            int i = 0;
            var confirmResult = MessageBox.Show("Are you sure to delete History??",
                                     "Confirm Delete!!",
                                     MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                try
                {
                    dbManager = new DataManager(DataProviderType.Sqlce, Constr);
                    dbManager.Open();



                    SQL = "DELETE FROM DB";
                    i = dbManager.ExecuteQuery(SQL);
                    if (i>0)
                    {
                        MessageBox.Show("Connection History Deleted");
                    }
                    else
                    {
                        MessageBox.Show("No data Found");
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    dbManager.Close();
                    Constr = string.Empty;
                    SQL = string.Empty;
                }
            }
            else
            {
              
            }
          

        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DataValidation frs = new DataValidation();
            frs.Show();
        }
    }
}
