﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataValidationTool.UC
{
    public partial class UC_SQL : UserControl
    {
        public string MSServer
        {
            get
            {
                return txtServer.Text.Trim();
            }
        }
        public string MSDB
        {
            get
            {
                return txtDB.Text.Trim();
            }
        }
        public string MSUID
        {
            get
            {
                return txtUid.Text.Trim();
            }
        }
        public string MSPWD
        {
            get
            {
                return txtPwd.Text.Trim();
            }
        }
        public bool Check
        {
            get
            {
                return checkBox1.Checked;
            }
        }
        public UC_SQL()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                txtUid.Enabled = true;
                txtPwd.Enabled = true;
            }
            else
            {
                txtUid.Enabled = false;
                txtPwd.Enabled = false;
                txtUid.Text = string.Empty;
                txtPwd.Text = string.Empty;
            }
        }

      
    }
}
