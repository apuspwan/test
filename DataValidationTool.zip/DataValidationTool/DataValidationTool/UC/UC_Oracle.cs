﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataValidationTool
{
    public partial class UC_Oracle : UserControl
    {
       
        public string DSN
        {
            get
            {
                return txtDSN.Text.Trim();
            }
        }
        public string Uid
        {
            get
            {
                return txtUid.Text.Trim();
            }
        }
        public string Password
        {
            get
            {
                return txtPass.Text.Trim();
            }
        }
        public UC_Oracle()
        {
            InitializeComponent();
           
        }

        

       

      
    }
}
