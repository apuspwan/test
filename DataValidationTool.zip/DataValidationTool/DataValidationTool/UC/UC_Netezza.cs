﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataValidationTool.UC
{
    public partial class UC_Netezza : UserControl
    {
        public string UserId
        {
            get
            {
                return txtUserId.Text.Trim();
            }
        }
        public string Pass
        {
            get
            {
                return txtPass.Text.Trim();
            }
        }
        public string DbName
        {
            get
            {
                return txtDbName.Text.Trim();
            }
        }

        public string Server
        {
            get
            {
                return  txtServName.Text.Trim();
            }
        }
        public string Port
        {
            get
            {
                return  txtPort.Text.Trim();
            }
        }
        public UC_Netezza()
        {
            InitializeComponent();
        }
    }
}
