﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectionDBFactory;
using Excel = Microsoft.Office.Interop.Excel;

namespace DataValidationTool
{
    public partial class Data_Validation : Form
    {
        string SQL1 = string.Empty, SQL2 = string.Empty;
       
      
        public Data_Validation()
        {
            InitializeComponent();
            //this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            //this.AutoSize = true;
            //this.Padding = new Padding(0, 0, 20, 20);
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void Data_Validation_Load(object sender, EventArgs e)
        {
            //string Constr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='D:\\DataValidationDB\\DataValidationDB.xlsx';Extended Properties=\"Excel 12.0;ReadOnly=False;HDR=Yes;\"";
            string Constr = @"Data Source=C:\DB\ETL.sdf";
            cmbSource.ResetText();
            cmbTarget.ResetText();
            DataTable dt = null, dt1 = null;
            try
            {
                string query = "select * from DB";
                dt = DAL.GetData(Constr, query, "sqlce");
                cmbSource.DataSource = dt;
                cmbSource.DisplayMember = "ConName";
                cmbSource.ValueMember = "Id";
                dt1 = DAL.GetData(Constr, query, "sqlce");
                cmbTarget.DataSource = dt1;
                cmbTarget.DisplayMember = "ConName";
                cmbTarget.ValueMember = "Id";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                Constr = string.Empty;
                dt = null;
                dt1 = null;
            }



           
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            if (txtSource.Text == string.Empty || txtTarget.Text == string.Empty)
            {
                MessageBox.Show("provide source and target SQL query..");
                return;
            }
            string SourceId = string.Empty, TargetId = string.Empty, DbSourceConStr = string.Empty, DbTargetConStr = string.Empty,SourceProvider=string.Empty,TargetProvider=string.Empty;
            string[] SourceCred = new string[3];
            string[] TargetCred = new string[3];
            DataTable SourceData = null, TargetData = null, ResultTable = null;
            string SourceDb=string.Empty,TargetDb=string.Empty;
            string SourceTop = string.Empty;
            string TargetTop = string.Empty;
           
            string SourcePath = string.Empty;
            string TargetPath = string.Empty;

            int SourceNew = 0, TargetNew = 0, SourceUnmatch = 0, SourceCount = 0, TargetCount = 0;

            string SourceSQL = string.Empty, TargetSQL = string.Empty;
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();

            folderDlg.ShowNewFolderButton = true;
            DialogResult result = folderDlg.ShowDialog();
            string Path = null;
      
            if (result == DialogResult.OK)
            {

                Path = folderDlg.SelectedPath;

            }

            SourceId = cmbSource.SelectedValue.ToString();
            TargetId = cmbTarget.SelectedValue.ToString();
            
            SourceCred = DAL.GetConStr(SourceId);
            TargetCred = DAL.GetConStr(TargetId);
            DbSourceConStr = SourceCred[0];
            DbTargetConStr = TargetCred[0];
            SourceProvider = SourceCred[1];
            TargetProvider = TargetCred[1];

            SourceDb=SourceCred[2];
            TargetDb=TargetCred[2];
            SourceSQL = txtSource.Text.Trim();
            TargetSQL = txtTarget.Text.Trim();

            //new varible for autoID
            string tblnamesrc = string.Empty, tblnametrg = string.Empty;
            try
            {
                //Write If condition for File Only.....
                //condition for if table has composite key or without nay key value...
                if (chkTable.Checked == true)
                {
                    if (SourceDb.Equals("Flat File"))
                    {

                        tblnamesrc = BAL.tblName(SourceSQL);

                        SourceSQL = BAL.GetQuery(SourceSQL);

                        SourcePath = DbSourceConStr + tblnamesrc + ".csv";
                        
                        //DbSourceConStr = "Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=" + System.IO.Path.GetDirectoryName(SourcePath) + ";Extensions=asc,csv,tab,txt;";
                       
                     

                        //SourceData = DAL.GetDataWithAutoId(DbSourceConStr, SourceProvider, SourceSQL);

                        SourceData = BAL.GetDataTabletFromCSVFile(SourcePath, ",");
                       
                     }
                    if (TargetDb.Equals("Flat File"))
                    {

                         tblnametrg = BAL.tblName(TargetSQL);

                         TargetSQL = BAL.GetQuery(TargetSQL);

                         TargetPath = DbTargetConStr + tblnametrg + ".csv";

                         //DbTargetConStr = "Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=" + System.IO.Path.GetDirectoryName(TargetPath) + ";Extensions=asc,csv,tab,txt;";

                        
                         //TargetData = DAL.GetDataWithAutoId(DbTargetConStr, TargetProvider, TargetSQL);
                         TargetData = BAL.GetDataTabletFromCSVFile(TargetPath, ",");
                       

                    }
                    if (SourceDb.Equals("Excel"))
                    {

                        DbSourceConStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + DbSourceConStr + "';Extended Properties=\"Excel 12.0;ReadOnly=False;HDR=Yes;\"";
                        SourceData = DAL.GetDataWithAutoId(DbSourceConStr, SourceProvider, SourceSQL);
                    }
                    if (TargetDb.Equals("Excel"))
                    {

                        DbTargetConStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + DbTargetConStr + "';Extended Properties=\"Excel 12.0;ReadOnly=False;HDR=Yes;\"";
                        TargetData = DAL.GetDataWithAutoId(DbTargetConStr, TargetProvider, TargetSQL);

                    }

                    //Code that need to change

                    if (SourceDb.Equals("Oracle") || SourceDb.Equals("My SQL") || SourceDb.Equals("Postgre SQL") || SourceDb.Equals("SAP HANA") || SourceDb.Equals("Teradata") || SourceDb.Equals("DB2") || SourceDb.Equals("Ingres") || SourceDb.Equals("Netezza") || SourceDb.Equals("MS SQL Server"))
                    {                   

                       SourceData = DAL.GetDataWithAutoId(DbSourceConStr, SourceProvider, SourceSQL);
                      
                    }
                    if (TargetDb.Equals("Oracle") || TargetDb.Equals("My SQL") || TargetDb.Equals("Postgre SQL") || TargetDb.Equals("SAP HANA") || TargetDb.Equals("Teradata") || TargetDb.Equals("DB2") || TargetDb.Equals("Ingres") || TargetDb.Equals("Netezza") || TargetDb.Equals("MS SQL Server"))
                    {


                       
                       TargetData = DAL.GetDataWithAutoId(DbTargetConStr, TargetProvider, TargetSQL);
                       
                    }
                }
                else
                {
                    if (SourceDb.Equals("Flat File"))
                    {

                        tblnamesrc = BAL.tblName(SourceSQL);

                        SourceSQL = BAL.GetQuery(SourceSQL);

                        SourcePath = DbSourceConStr + tblnamesrc + ".csv";


                        //DbSourceConStr = "Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=" + System.IO.Path.GetDirectoryName(SourcePath) + ";Extensions=asc,csv,tab,txt;";


                        //SourceData =DAL.GetData(DbSourceConStr, SourceSQL, SourceProvider);

                        SourceData = BAL.GetDataTabletFromCSVFile(SourcePath, ",");
                    }
                    if (TargetDb.Equals("Flat File"))
                    {

                        tblnametrg = BAL.tblName(TargetSQL);

                        TargetSQL = BAL.GetQuery(TargetSQL);

                        TargetPath = DbTargetConStr + tblnametrg + ".csv";

                        //DbTargetConStr = "Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=" + System.IO.Path.GetDirectoryName(TargetPath) + ";Extensions=asc,csv,tab,txt;";



                        //TargetData = DAL.GetData(DbTargetConStr, TargetSQL, TargetProvider);

                        TargetData = BAL.GetDataTabletFromCSVFile(TargetPath, ",");
                       
                  
                    }
                    if (SourceDb.Equals("Excel"))
                    {

                        DbSourceConStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + DbSourceConStr + "';Extended Properties=\"Excel 12.0;ReadOnly=False;HDR=Yes;\"";
                        SourceData = DAL.GetData(DbSourceConStr, SourceSQL, SourceProvider);
                    }
                    if (TargetDb.Equals("Excel"))
                    {

                        DbTargetConStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + DbTargetConStr + "';Extended Properties=\"Excel 12.0;ReadOnly=False;HDR=Yes;\"";
                        TargetData = DAL.GetData(DbTargetConStr, TargetSQL, TargetProvider);

                    }
                    //Code that need to change
                    if (SourceDb.Equals("Oracle") || SourceDb.Equals("My SQL") || SourceDb.Equals("Postgre SQL") || SourceDb.Equals("SAP HANA") || SourceDb.Equals("Teradata") || SourceDb.Equals("DB2") || SourceDb.Equals("Ingres") || SourceDb.Equals("Netezza")||SourceDb.Equals("MS SQL Server"))
                    {
                        SourceData = DAL.GetData(DbSourceConStr, SourceSQL, SourceProvider);
                    }
                    if (TargetDb.Equals("Oracle") || TargetDb.Equals("My SQL") || TargetDb.Equals("Postgre SQL") || TargetDb.Equals("SAP HANA") || TargetDb.Equals("Teradata") || TargetDb.Equals("DB2") || TargetDb.Equals("Ingres") || TargetDb.Equals("Netezza") || TargetDb.Equals("MS SQL Server"))
                    {
                        TargetData = DAL.GetData(DbTargetConStr, TargetSQL, TargetProvider);
                    }

                }


                ResultTable = BAL.DataComapePrimaryKey(SourceData, TargetData);

                if (ResultTable.Rows.Count > 0)
                {
                    SourceNew = (from p in ResultTable.AsEnumerable()
                                 where p.Field<string>("Comment") == "new in src"
                                 select p).Count();

                    TargetNew = (from p in ResultTable.AsEnumerable()
                                 where p.Field<string>("Comment") == "new in trg"
                                 select p).Count();

                    SourceUnmatch = (from p in ResultTable.AsEnumerable()
                                     where p.Field<string>("Comment") == "src"
                                     select p).Count();

                    SourceCount = SourceData.Rows.Count;
                    TargetCount = TargetData.Rows.Count;


                   
                  //Getexcel(ResultTable, Path, SourceNew, TargetNew, SourceUnmatch);

                 callprocess(ResultTable, Path, SourceNew, TargetNew, SourceUnmatch);
                    DateTime d = DateTime.Now;


                    DAL.InsertReport(d, SourceDb, TargetDb, "DataValidation", SourceCount, TargetCount, SourceNew, TargetNew, SourceUnmatch);

                }
                else
                {
                    lblSourceCount.Text = "0";
                    lblTargetCount.Text = "0";
                    lblSourceNew.Text = "0";

                    lblTargetNew.Text = "0";

                    lblUnmatched.Text = "0";
                    MessageBox.Show("Both Tables have identical data...");
                }
                SourceCount = SourceData.Rows.Count;

                TargetCount = TargetData.Rows.Count;



                lblSourceCount.Text = SourceCount.ToString();



                lblTargetCount.Text = TargetCount.ToString();

                lblSourceNew.Text = SourceNew.ToString();

                lblTargetNew.Text = TargetNew.ToString();

                lblUnmatched.Text = SourceUnmatch.ToString();
                    
              
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                SourceData = null;
                TargetData = null;
              
                ResultTable = null;
                SourceTop = string.Empty;
                TargetTop = string.Empty;
          
                SourcePath = string.Empty;
                TargetPath = string.Empty;
                Path = string.Empty;
                SourceDb = string.Empty;
                TargetDb = string.Empty;
                SourceSQL = string.Empty;
                TargetSQL = string.Empty;
                SourceId = string.Empty; 
                TargetId = string.Empty;
                DbSourceConStr = string.Empty;
                DbTargetConStr = string.Empty;
                SourceProvider = string.Empty;
                TargetProvider = string.Empty;
               
            }
        }

        public async void callprocess(DataTable dt, string Path, int sourcenew, int targetnew, int unmatch)
        {
            await Getexcel(dt,Path,sourcenew,targetnew,unmatch);
        }

        public  Task Getexcel(DataTable dt, string Path, int sourcenew, int targetnew, int unmatch)
        {
            return Task.Run(() =>
            {
                DataTable t1 = null, t2 = null, t3 = null, t4 = null;

                Excel.Application xlApp;
                Excel.Workbook xlWorkBook = null;

                object misValue = System.Reflection.Missing.Value;

                xlApp = new Excel.Application();
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                Excel.Sheets worksheets = xlWorkBook.Worksheets;

                var xlWorkSheet = (Excel.Worksheet)worksheets.Add(worksheets[1], Type.Missing, Type.Missing, Type.Missing);
                var xlWorkSheet1 = (Excel.Worksheet)worksheets.Add(worksheets[2], Type.Missing, Type.Missing, Type.Missing);
                var xlWorkSheet2 = (Excel.Worksheet)worksheets.Add(worksheets[3], Type.Missing, Type.Missing, Type.Missing);
                var xlWorkSheet3 = (Excel.Worksheet)worksheets.Add(worksheets[4], Type.Missing, Type.Missing, Type.Missing);
                //Excel.Range usedrange = xlWorkSheet.UsedRange;
                Excel.Range usedrange1 = xlWorkSheet2.UsedRange;
                Excel.Range usedrange2 = xlWorkSheet3.UsedRange;

                string slas = "\\";
                xlWorkSheet.Name = "New in Source";
                xlWorkSheet1.Name = "New in Target";
                xlWorkSheet2.Name = "Un-matched in Source";
                xlWorkSheet3.Name = "Un-matched in Target";

                for (int i = 1; i < dt.Columns.Count; i++)
                {
                    xlWorkSheet.Cells[1, i] = dt.Columns[i - 1].ColumnName;
                    xlWorkSheet1.Cells[1, i] = dt.Columns[i - 1].ColumnName;
                    xlWorkSheet2.Cells[1, i] = dt.Columns[i - 1].ColumnName;
                    xlWorkSheet3.Cells[1, i] = dt.Columns[i - 1].ColumnName;

                }

                if (sourcenew > 0)
                {
                    t1 = (from a in dt.AsEnumerable()
                          where a.Field<string>("Comment") == "new in src"
                          select a).CopyToDataTable();

                    for (int i = 0; i < t1.Rows.Count; i++)
                    {
                        for (int j = 0; j < t1.Columns.Count - 1; j++)
                        {
                            xlWorkSheet.Cells[i + 2, j + 1] = t1.Rows[i][j].ToString();
                        }
                    }
                }
                if (targetnew > 0)
                {
                    t2 = (from a in dt.AsEnumerable()
                          where a.Field<string>("Comment") == "new in trg"
                          select a).CopyToDataTable();

                    for (int i = 0; i < t2.Rows.Count; i++)
                    {
                        for (int j = 0; j < t2.Columns.Count - 1; j++)
                        {
                            xlWorkSheet1.Cells[i + 2, j + 1] = t2.Rows[i][j].ToString();
                        }
                    }

                }
                if (unmatch > 0)
                {
                    t3 = (from a in dt.AsEnumerable()
                          where a.Field<string>("Comment") == "src"
                          select a).CopyToDataTable();
                    t4 = (from a in dt.AsEnumerable()
                          where a.Field<string>("Comment") == "trg"
                          select a).CopyToDataTable();

                    for (int i = 0; i < t3.Rows.Count; i++)
                    {
                        for (int j = 0; j < t3.Columns.Count - 1; j++)
                        {
                            if (t3.Rows[i][j].ToString() == t4.Rows[i][j].ToString())
                            {
                                xlWorkSheet2.Cells[i + 2, j + 1] = t3.Rows[i][j].ToString();
                                xlWorkSheet3.Cells[i + 2, j + 1] = t4.Rows[i][j].ToString();
                            }
                            else
                            {
                                xlWorkSheet2.Cells[i + 2, j + 1] = t3.Rows[i][j].ToString();
                                xlWorkSheet3.Cells[i + 2, j + 1] = t4.Rows[i][j].ToString();
                                Excel.Range rab1 = usedrange1.Cells[i + 2, j + 1];
                                Excel.Range rab2 = usedrange2.Cells[i + 2, j + 1];
                                rab1.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                                rab2.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                            }
                        }
                    }

                }

                xlWorkSheet.Select();

                xlWorkSheet1.Select();
                xlWorkSheet2.Select();

                xlWorkSheet3.Select();


                Random rno = new Random();
                string rno_ = Convert.ToString(rno.Next());
                xlWorkBook.SaveAs(@"" + Path + "" + slas + "DataValidation_" + rno_ + ".xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();
                t1 = null;
                t2 = null;
                t3 = null;
                t4 = null;

                BAL.releaseObject(xlWorkSheet);
                BAL.releaseObject(xlWorkSheet1);
                BAL.releaseObject(xlWorkSheet2);
                BAL.releaseObject(xlWorkSheet3);
                BAL.releaseObject(xlWorkBook);
                BAL.releaseObject(xlApp);

                MessageBox.Show("Data exported in " + Path + "" + slas + "DataValidation_" + rno_ + "");
            });
        }



        public void Getexcel1(DataTable dt, string Path,int source,int target)
        {
            DataTable t1 = null, t2 = null;

            Excel.Application xlApp;
            Excel.Workbook xlWorkBook = null;



            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            Excel.Sheets worksheets = xlWorkBook.Worksheets;

            var xlWorkSheet = (Excel.Worksheet)worksheets.Add(worksheets[1], Type.Missing, Type.Missing, Type.Missing);
           var xlWorkSheet1 = (Excel.Worksheet)worksheets.Add(worksheets[2], Type.Missing, Type.Missing, Type.Missing);

            //Excel.Range usedrange = xlWorkSheet.UsedRange;
            Excel.Range usedrange1 = xlWorkSheet.UsedRange;
            Excel.Range usedrange2 = xlWorkSheet1.UsedRange;


            string slas = "\\";
            xlWorkSheet.Name = "Source";
            xlWorkSheet1.Name = "Target";


            for (int i = 1; i < dt.Columns.Count; i++)
            {
                xlWorkSheet.Cells[1, i] = dt.Columns[i - 1].ColumnName;
                xlWorkSheet1.Cells[1, i] = dt.Columns[i - 1].ColumnName;


            }


            //if(source>0)
            //{
                 t1 = (from a in dt.AsEnumerable()
                      where a.Field<string>("Comment") == "src"
                      select a).CopyToDataTable();

                 t2 = (from a in dt.AsEnumerable()
                       where a.Field<string>("Comment") == "trg"
                       select a).CopyToDataTable();
                 try
                 {
                     for (int i = 0; i < t1.Rows.Count; i++)
                     {
                         for (int j = 0; j < t1.Columns.Count - 1; j++)
                         {
                             if (t1.Rows[i][j].ToString() == t2.Rows[i][j].ToString())
                             {
                                 xlWorkSheet.Cells[i + 2, j + 1] = t1.Rows[i][j].ToString();
                                 xlWorkSheet1.Cells[i + 2, j + 1] = t2.Rows[i][j].ToString();
                             }
                             else
                             {
                                 xlWorkSheet.Cells[i + 2, j + 1] = t1.Rows[i][j].ToString();
                                 xlWorkSheet1.Cells[i + 2, j + 1] = t2.Rows[i][j].ToString();
                                 Excel.Range rab1 = usedrange1.Cells[i + 2, j + 1];
                                 Excel.Range rab2 = usedrange2.Cells[i + 2, j + 1];
                                 rab1.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                                 rab2.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                             }
                         }
                     }
                 }
            catch(Exception ex)
                 {
                     throw ex;
            }
            finally
                 {

                 }
              



            //}
            //if(target>0)
            //{
                 
                 //for (int i = 0; i < t2.Rows.Count; i++)
                 //{
                 //    for (int j = 0; j < t2.Columns.Count - 1; j++)
                 //    {
                 //        xlWorkSheet1.Cells[i + 2, j + 1] = t2.Rows[i][j].ToString();
                 //    }
                 //}
            //}
           
           

           
            //for (int i = 0; i < dt.Rows.Count; i++)
            //{
            //    for (int j = 0; j < dt.Columns.Count; j++)
            //    {
            //        if (dt.Rows[i][j].ToString() == dt.Rows[i][j].ToString())
            //        {
            //            xlWorkSheet.Cells[i + 2, j + 1] = t1.Rows[i][j].ToString();
            //            //xlWorkSheet1.Cells[i + 2, j + 1] = t2.Rows[i][j].ToString();
            //        }
            //        else
            //        {

            //        xlWorkSheet.Cells[i + 2, j + 1] = dt.Rows[i][j].ToString();
            //            //xlWorkSheet1.Cells[i + 2, j + 1] = t2.Rows[i][j].ToString();
            //            Excel.Range rab1 = usedrange1.Cells[i + 2, j + 1];
            //            //Excel.Range rab2 = usedrange2.Cells[i + 2, j + 1];
            //        //    rab1.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
            //        //    //rab2.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
            //        }
            //    }
            //}








            xlWorkSheet.Select();

            xlWorkSheet1.Select();



            Random rno = new Random();
            string rno_ = Convert.ToString(rno.Next());
            xlWorkBook.SaveAs(@"" + Path + "" + slas + "DataValidation_" + rno_ + ".xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            t1 = null;
            t2 = null;


            BAL.releaseObject(xlWorkSheet);
            BAL.releaseObject(xlWorkSheet1);

            BAL.releaseObject(xlWorkBook);
            BAL.releaseObject(xlApp);

            MessageBox.Show("Data exported in " + Path + "" + slas + "DataValidation_" + rno_ + "");
        }
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DataValidation frs = new DataValidation();
            frs.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

       
    }
}
