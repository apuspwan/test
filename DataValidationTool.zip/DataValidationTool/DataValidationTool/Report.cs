﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectionDBFactory;
using Excel = Microsoft.Office.Interop.Excel; 

namespace DataValidationTool
{
    public partial class Report : Form
    {
        public Report()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        

        private void btnShow_Click_1(object sender, EventArgs e)
        {

          
            DateTime idate1, idate2;
            idate1 = datePick1.Value;
            idate2 = datePick2.Value;


            string Constr = @"Data Source=C:\DB\ETL.sdf";
            DataTable dt = null;
            try
            {
                string SQL = "select * from Report where Date Between '" + Convert.ToDateTime(idate1) + "' and '" + Convert.ToDateTime(idate2) + "'";
                dt = DAL.GetData(Constr, SQL, "sqlce");
                grdData.DataSource = dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                
                Constr = string.Empty;
                dt = null;

            }
            btnExport.Visible = true;
        }

        private void btnPrev_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DataValidation frs = new DataValidation();
            frs.Show();
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();

            folderDlg.ShowNewFolderButton = true;
            DialogResult result = folderDlg.ShowDialog();
            string Path = null;

            if (result == DialogResult.OK)
            {

                Path = folderDlg.SelectedPath;

            }
            Excel.Application xlApp;
            Excel.Workbook xlWorkBook = null;

            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            Excel.Sheets worksheets = xlWorkBook.Worksheets;

            var xlWorkSheet = (Excel.Worksheet)worksheets.Add(worksheets[1], Type.Missing, Type.Missing, Type.Missing);
         
               
            
            string slas = "\\";
            xlWorkSheet.Name = "Report";
           
            for (int i = 1; i < grdData.Columns.Count+1; i++)
            {
                xlWorkSheet.Cells[1, i] = grdData.Columns[i - 1].HeaderText;
              

            }
    
            for (int i = 0; i < grdData.RowCount - 1; i++)
            {
                for (int j = 0; j < grdData.ColumnCount; j++)
                {
                    DataGridViewCell cell = grdData[j,i];
                    xlWorkSheet.Cells[i + 2, j + 1] = cell.Value;
                }
            }
            xlWorkSheet.Select();
            Random rno = new Random();
            string rno_ = Convert.ToString(rno.Next());
            xlWorkBook.SaveAs(@"" + Path + "" + slas + "Report_" + rno_ + ".xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

            xlWorkBook.Close(true, misValue, misValue);
            BAL.releaseObject(xlWorkSheet);
            BAL.releaseObject(xlWorkBook);
            BAL.releaseObject(xlApp);

            MessageBox.Show("Report exported in " + Path + "" + slas + "Report_" + rno_ + "");
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
