﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataValidationTool
{
    public partial class DataValidation : Form
    {
        string strConName = null, strdb = null;
        public DataValidation()
        {
            InitializeComponent();
            //this.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            //this.AutoSize = true;
            //this.Padding = new Padding(0, 0, 20, 20);
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void craeteConnectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pnlAddCon.Visible = true;
            btnExit.Visible = true;
            btnNext.Visible = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
            
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            
            strConName = txtConName.Text.Trim();
            strdb = cmbDb.Text;
            if ((strConName == "") || (strdb==""))
            {
                MessageBox.Show("Please Input conection name...");
                return;
            }
           
                this.Hide();
                Connection_Template frs = new Connection_Template(strConName, strdb);
                frs.Show();

                    
            
        }

        private void DataValidation_Load(object sender, EventArgs e)
        {
            cmbDb.Items.Add("Oracle");
            cmbDb.Items.Add("MS SQL Server");
            cmbDb.Items.Add("My SQL");
            cmbDb.Items.Add("Postgre SQL");
            cmbDb.Items.Add("SAP HANA");
            cmbDb.Items.Add("Teradata");
            cmbDb.Items.Add("DB2");
            cmbDb.Items.Add("Ingres");
            cmbDb.Items.Add("Netezza");
            cmbDb.Items.Add("Access");
            cmbDb.Items.Add("Excel");
            cmbDb.Items.Add("Flat File");
        }

        private void dataValidationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            
            Data_Validation frs = new Data_Validation();
            frs.Show();
           
        }

      

        private void twoTablesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Structure_Validation frs = new Structure_Validation();
            frs.Show();
        }

        private void reportsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report frs = new Report();
            frs.Show();
        }

        private void fileToFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            File_To_File frs = new File_To_File();
            frs.Show();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AboutBox1 frs = new AboutBox1();
            frs.Show();
        }

        private void settingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Setting frs = new Setting();

            frs.Show();
        }

        private void multipleTableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            DbToFile frs = new DbToFile();

            frs.Show();
        }

      

      

        

      

      
    }
}
