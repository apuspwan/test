﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using ConnectionDBFactory;
using Excel = Microsoft.Office.Interop.Excel;

namespace DataValidationTool
{
    public partial class File_To_File : Form
    {
        public File_To_File()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        string Constr = string.Empty, ConProvider = string.Empty, ConDb = string.Empty, SQL = string.Empty,conId = string.Empty;
       
        string[] ConCred = new string[3];
        private void pnlList_Paint(object sender, PaintEventArgs e)
        {
            //var Items = checkedListBox1.Items;
            //Items.Add("Oracle", true);
            //Items.Add("MS", true);
            //Items.Add("SAP");
           
        }

        private void File_To_File_Load(object sender, EventArgs e)
        {
            string Constr = @"Data Source=C:\DB\ETL.sdf";
            cmbConection.ResetText();

            DataTable dt = null;
            try
            {
                string query = "select * from DB where DB in('Excel')";
                dt = DAL.GetData(Constr, query, "sqlce");
                cmbConection.DataSource = dt;
                cmbConection.DisplayMember = "ConName";
                cmbConection.ValueMember = "Id";

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                Constr = string.Empty;
                dt = null;

            }
        }

      

        private void btnShow_Click(object sender, EventArgs e)
        {
          
            conId = cmbConection.SelectedValue.ToString();
            ConCred = DAL.GetConStr(conId);
            Constr = ConCred[0];
            ConProvider = ConCred[1];
            ConDb = ConCred[2];
            Constr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + Constr + "';Extended Properties=\"Excel 12.0;ReadOnly=False;HDR=Yes;\"";

            SQL = "select distinct Source_Table from [Data$]";
            DataTable Source = DAL.GetData(Constr, SQL, ConProvider);
            foreach (DataRow dr in Source.Rows)
            {
                string str = dr["Source_Table"].ToString();
                checkedListBox1.Items.Add(str,true);
            }
            SQL = "select distinct Target_Table from [Data$]";
            DataTable Target = DAL.GetData(Constr, SQL, ConProvider);
            foreach (DataRow dr in Target.Rows)
            {
                string str = dr["Target_Table"].ToString();
                checkedListBox2.Items.Add(str,true);
            }
            /////
           

        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderDlg = new FolderBrowserDialog();

            folderDlg.ShowNewFolderButton = true;
            DialogResult result = folderDlg.ShowDialog();
            string Path = null;

            if (result == DialogResult.OK)
            {

                Path = folderDlg.SelectedPath;

            }
            DataTable Source = null, Target = null;
            SQL = "select Source_Table,Source_Column,Source_Type from [Data$]";
            Source = DAL.GetData(Constr, SQL, ConProvider);

            SQL = "select Target_Table,Target_Column,Target_Type from [Data$]";

            Target = DAL.GetData(Constr, SQL, ConProvider);

            Getexcel(Source, Target, Path);

        }
   
        public void Getexcel(DataTable dt1,DataTable dt2, string Path)
        {
            Excel.Application xlApp;
            Excel.Workbook xlWorkBook = null;



            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            Excel.Sheets worksheets = xlWorkBook.Worksheets;

            var xlWorkSheet = (Excel.Worksheet)worksheets.Add(worksheets[1], Type.Missing, Type.Missing, Type.Missing);
            var xlWorkSheet1 = (Excel.Worksheet)worksheets.Add(worksheets[2], Type.Missing, Type.Missing, Type.Missing);
          
            Excel.Range usedrange1 = xlWorkSheet.UsedRange;
            Excel.Range usedrange2 = xlWorkSheet1.UsedRange;
           

            string slas = "\\";
            xlWorkSheet.Name = "Source";
            xlWorkSheet1.Name = "Target";




            for (int i = 1; i < dt1.Columns.Count+1; i++)
            {
                xlWorkSheet.Cells[1, i] = dt1.Columns[i-1].ColumnName;
             
             
               
            }
            for (int i = 1; i < dt2.Columns.Count+1; i++)
            {
                
                xlWorkSheet1.Cells[1, i] = dt2.Columns[i-1].ColumnName;


            }

            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                for (int j = 0; j < dt2.Columns.Count; j++)
                {
                    if (dt1.Rows[i][j].ToString() == dt2.Rows[i][j].ToString())
                    {
                        xlWorkSheet.Cells[i + 2, j + 1] = dt1.Rows[i][j].ToString();
                        xlWorkSheet1.Cells[i + 2, j + 1] = dt2.Rows[i][j].ToString();
                    }
                    else
                    {
                        xlWorkSheet.Cells[i + 2, j + 1] = dt1.Rows[i][j].ToString();
                        xlWorkSheet1.Cells[i + 2, j + 1] = dt2.Rows[i][j].ToString();
                        Excel.Range rab1 = usedrange1.Cells[i + 2, j + 1];
                        Excel.Range rab2 = usedrange2.Cells[i + 2, j + 1];
                        rab1.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                        rab2.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                    }
                }
            }

            xlWorkSheet.Select();

            xlWorkSheet1.Select();
           

            Random rno = new Random();
            string rno_ = Convert.ToString(rno.Next());
            xlWorkBook.SaveAs(@"" + Path + "" + slas + "StuctureValidation_" + rno_ + ".xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
           

            BAL.releaseObject(xlWorkSheet);
            BAL.releaseObject(xlWorkSheet1);
          
            BAL.releaseObject(xlWorkBook);
            BAL.releaseObject(xlApp);

            MessageBox.Show("Data exported in " + Path + "" + slas + "StuctureValidation_" + rno_ + "");
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DataValidation frs = new DataValidation();
            frs.Show();

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
