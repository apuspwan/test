﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectionDBFactory;
using Excel = Microsoft.Office.Interop.Excel;

namespace DataValidationTool
{
    public partial class DbToFile : Form
    {
        public DbToFile()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void DbToFile_Load(object sender, EventArgs e)
        {
            string Constr = @"Data Source=C:\DB\ETL.sdf";
            DataTable dt = null, dt1 = null;
            try
            {

                string query = "select * from DB";
                dt = DAL.GetData(Constr, query, "sqlce");
                cmbSource.DataSource = dt;
                cmbSource.DisplayMember = "ConName";
                cmbSource.ValueMember = "Id";
                dt1 = DAL.GetData(Constr, query, "sqlce");
                cmbTarget.DataSource = dt1;
                cmbTarget.DisplayMember = "ConName";
                cmbTarget.ValueMember = "Id";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Constr = string.Empty;
                dt = null;
                dt1 = null;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DataValidation frs = new DataValidation();
            frs.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
         public static string GetSql(string SQL)
        {
            string SourceFileName = BAL.GetQuery(SQL);
            string[] Str = SourceFileName.Split('.');
            string OrignalTableName = Str[0];
            string Result = SQL.Replace(OrignalTableName, SourceFileName);
            return Result;
                        
        }
        private void btnProcess_Click(object sender, EventArgs e)
        {
            if ((txtSource.Text == "") || (txtTarget.Text == ""))
            {
                MessageBox.Show("please input target and source datatable name...");
                return;
            }
            string SourceTable = txtSource.Text.Trim(), TargetTable = txtTarget.Text.Trim();
            string SourceId = string.Empty, TargetId = string.Empty, DbSourceConStr = string.Empty, DbTargetConStr = string.Empty, SourceProvider = string.Empty, TargetProvider = string.Empty, SourceDb = string.Empty, TargetDb = string.Empty;
            string[] SourceCred = new string[3];
            string[] TargetCred = new string[3];
            DataTable SourceData = null, TargetData = null;

            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = true;
            DialogResult result = folderDlg.ShowDialog();
            string Path = null;

            if (result == DialogResult.OK)
            {

                Path = folderDlg.SelectedPath;

            }
            SourceId = cmbSource.SelectedValue.ToString();
            TargetId = cmbTarget.SelectedValue.ToString();

            SourceCred = DAL.GetConStr(SourceId);
            TargetCred = DAL.GetConStr(TargetId);
            DbSourceConStr = SourceCred[0];
            DbTargetConStr = TargetCred[0];
            SourceProvider = SourceCred[1];
            TargetProvider = TargetCred[1];
            SourceDb = SourceCred[2];
            TargetDb = TargetCred[2];
            if (SourceDb.Equals("Flat File") && (TargetDb.Equals("Oracle") || TargetDb.Equals("SAP HANA")) || TargetDb.Equals("MS SQL Server"))
            {


            string sourcepath = DbSourceConStr + SourceTable + ".csv";
            string SourceTable1 = SourceTable + ".csv";
            string SourceSQL = "select * from " + SourceTable1 + "";
            DbSourceConStr = "Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=" + System.IO.Path.GetDirectoryName(sourcepath) + ";Extensions=asc,csv,tab,txt;";
            SourceData = DAL.GetData(DbSourceConStr, SourceSQL, SourceProvider);
            TargetData = DAL.GetDataStruture(DbTargetConStr, TargetTable, TargetProvider, TargetTable);
            }
            else
            {


                string sourcepath = DbTargetConStr + TargetTable + ".csv";
                string SourceTable1 = TargetTable + ".csv";
                string SourceSQL = "select * from " + SourceTable1 + "";
                DbTargetConStr = "Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=" + System.IO.Path.GetDirectoryName(sourcepath) + ";Extensions=asc,csv,tab,txt;";
                SourceData = DAL.GetDataStruture(DbSourceConStr, SourceTable, SourceProvider, SourceTable);
                TargetData = DAL.GetData(DbTargetConStr, SourceSQL, TargetProvider);
            }
            //ResultData = BAL.GetSchemaMatch(SourceData, TargetData);

            int SourceCount = 0, TargetCount = 0;
            SourceCount = SourceData.Rows.Count; ;
            TargetCount = TargetData.Rows.Count;
            lblSourceCount.Text = Convert.ToString(SourceCount);
            lblTargetCount.Text = Convert.ToString(TargetCount);
            Getexcel(SourceData, TargetData, Path);
        }
        public void Getexcel(DataTable dt1, DataTable dt2, string Path)
        {
            var var1 = dt1.AsEnumerable().Except(dt2.AsEnumerable(), System.Data.DataRowComparer.Default);
            var var2 = dt2.AsEnumerable().Except(dt1.AsEnumerable(), System.Data.DataRowComparer.Default);

            DataTable test = new DataTable();

            test = var1.CopyToDataTable();

            Excel.Application xlApp;
            Excel.Workbook xlWorkBook = null;

            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            Excel.Sheets worksheets = xlWorkBook.Worksheets;

            var xlWorkSheet = (Excel.Worksheet)worksheets.Add(worksheets[1], Type.Missing, Type.Missing, Type.Missing);
            var xlWorkSheet1 = (Excel.Worksheet)worksheets.Add(worksheets[2], Type.Missing, Type.Missing, Type.Missing);

            Excel.Range usedrange1 = xlWorkSheet.UsedRange;
            Excel.Range usedrange2 = xlWorkSheet1.UsedRange;


            string slas = "\\";
            xlWorkSheet.Name = "Source";
            xlWorkSheet1.Name = "Target";


            for (int i = 1; i < dt1.Columns.Count + 1; i++)
            {

                xlWorkSheet.Cells[1, i] = dt1.Columns[i - 1].ColumnName;

                xlWorkSheet1.Cells[1, i] = dt1.Columns[i - 1].ColumnName;

            }

            //Test 


            //End Test



            int Row = 0, Col = 0,SourceTableCount=0,TargetTableCount=0,WhichIsGreater=0;
            SourceTableCount = dt1.Rows.Count;
            TargetTableCount = dt2.Rows.Count;
            WhichIsGreater = BAL.GreaterRows(SourceTableCount, TargetTableCount);


            for (Row = 0; Row < SourceTableCount; Row++)
                {

                    for (Col = 0; Col < dt2.Columns.Count; Col++)
                    {
                        
                        if (dt1.Rows[Row][Col].ToString() == dt2.Rows[Row][Col].ToString())
                        {
                            xlWorkSheet.Cells[Row + 2, Col + 1] = dt1.Rows[Row][Col].ToString();

                            xlWorkSheet1.Cells[Row + 2, Col + 1] = dt2.Rows[Row][Col].ToString();
                        }
                        else
                        {
                            xlWorkSheet.Cells[Row + 2, Col + 1] = dt1.Rows[Row][Col].ToString();
                            xlWorkSheet1.Cells[Row + 2, Col + 1] = dt2.Rows[Row][Col].ToString();
                            Excel.Range rab1 = usedrange1.Cells[Row + 2, Col + 1];
                            Excel.Range rab2 = usedrange2.Cells[Row + 2, Col + 1];
                            rab1.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                            rab2.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);

                        }
                     
                    }


                }
          
         



            xlWorkSheet.Select();

            //xlWorkSheet1.Select();


            Random rno = new Random();
            string rno_ = Convert.ToString(rno.Next());
            xlWorkBook.SaveAs(@"" + Path + "" + slas + "StuctureValidation_" + rno_ + ".xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();


            BAL.releaseObject(xlWorkSheet);
            BAL.releaseObject(xlWorkSheet1);

            BAL.releaseObject(xlWorkBook);
            BAL.releaseObject(xlApp);

            MessageBox.Show("Data exported in " + Path + "" + slas + "StuctureValidation_" + rno_ + "");

        }
    }
}
