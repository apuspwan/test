﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectionDBFactory;
using Excel = Microsoft.Office.Interop.Excel;

namespace DataValidationTool
{
    public partial class Structure_Validation : Form
    {
        string SQL1 = string.Empty, SQL2 = string.Empty;
       
        public Structure_Validation()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DataValidation frs = new DataValidation();
            frs.Show();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            if ((txtSource.Text == "") || (txtTarget.Text == ""))
            {
                MessageBox.Show("please input target and source datatable name...");
                return;
            }
            string SourceTable = txtSource.Text.Trim(), TargetTable = txtTarget.Text.Trim();
            string SourceId = string.Empty, TargetId = string.Empty, DbSourceConStr = string.Empty, DbTargetConStr = string.Empty, SourceProvider = string.Empty, TargetProvider = string.Empty, SourceDb = string.Empty, TargetDb = string.Empty;
            string[] SourceCred = new string[3];
            string[] TargetCred = new string[3];
            DataTable SourceData = null, TargetData = null;

            FolderBrowserDialog folderDlg = new FolderBrowserDialog();
            folderDlg.ShowNewFolderButton = true;
            DialogResult result = folderDlg.ShowDialog();
            string Path = null;

            if (result == DialogResult.OK)
            {

                Path = folderDlg.SelectedPath;

            }
            SourceId = cmbSource.SelectedValue.ToString();
            TargetId = cmbTarget.SelectedValue.ToString();

            SourceCred = DAL.GetConStr(SourceId);
            TargetCred = DAL.GetConStr(TargetId);
            DbSourceConStr = SourceCred[0];
            DbTargetConStr = TargetCred[0];
            SourceProvider = SourceCred[1];
            TargetProvider = TargetCred[1];
            SourceDb = SourceCred[2];
            TargetDb = TargetCred[2];

            SourceData = DAL.GetDataStruture(DbSourceConStr, SourceTable, SourceProvider, SourceTable);
            TargetData = DAL.GetDataStruture(DbTargetConStr, TargetTable, TargetProvider, TargetTable);

            //ResultData = BAL.GetSchemaMatch(SourceData, TargetData);

            int SourceCount = 0, TargetCount = 0;
            SourceCount = SourceData.Rows.Count; ;
            TargetCount=TargetData.Rows.Count;
            lblSourceCount.Text = Convert.ToString(SourceCount);
            lblTargetCount.Text = Convert.ToString(TargetCount);
            Getexcel(SourceData, TargetData, Path);
            //DateTime date = DateTime.Now;
            //string d = date.ToString("d");
            //DAL.InsertReport(d, SourceDb, TargetDb, "StructureValidation of DB to DB", SourceCount, TargetCount, SourceNew, TargetNew, SourceUnmatch);
        

        }
        public void Getexcel(DataTable dt1, DataTable dt2, string Path)
        {
            Excel.Application xlApp;
            Excel.Workbook xlWorkBook = null;
            
            object misValue = System.Reflection.Missing.Value;

            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            Excel.Sheets worksheets = xlWorkBook.Worksheets;

            var xlWorkSheet = (Excel.Worksheet)worksheets.Add(worksheets[1], Type.Missing, Type.Missing, Type.Missing);
            var xlWorkSheet1 = (Excel.Worksheet)worksheets.Add(worksheets[2], Type.Missing, Type.Missing, Type.Missing);

            Excel.Range usedrange1 = xlWorkSheet.UsedRange;
            Excel.Range usedrange2 = xlWorkSheet1.UsedRange;


            string slas = "\\";
            xlWorkSheet.Name = "Source";
            xlWorkSheet1.Name = "Target";

            
            for (int i = 1; i < dt1.Columns.Count + 1; i++)
            {
                xlWorkSheet.Cells[1, i] = dt1.Columns[i - 1].ColumnName;

                xlWorkSheet1.Cells[1, i] = dt1.Columns[i - 1].ColumnName;
            }
           
            //Test 
           

            //End Test
            for (int i = 0; i < dt1.Rows.Count; i++)
            {
                
                    for (int j = 0; j < dt2.Columns.Count; j++)
                    {

                       
                            if (dt1.Rows[i][j].ToString() == dt2.Rows[i][j].ToString())
                            {
                                xlWorkSheet.Cells[i + 2, j + 1] = dt1.Rows[i][j].ToString();
                                xlWorkSheet1.Cells[i + 2, j + 1] = dt2.Rows[i][j].ToString();
                            }
                            else
                            {
                                xlWorkSheet.Cells[i + 2, j + 1] = dt1.Rows[i][j].ToString();
                                xlWorkSheet1.Cells[i + 2, j + 1] = dt2.Rows[i][j].ToString();
                                Excel.Range rab1 = usedrange1.Cells[i + 2, j + 1];
                                Excel.Range rab2 = usedrange2.Cells[i + 2, j + 1];
                                rab1.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                                rab2.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Yellow);
                            }
                           
              }
                                           
              
            }


                     
            xlWorkSheet.Select();

            //xlWorkSheet1.Select();


            Random rno = new Random();
            string rno_ = Convert.ToString(rno.Next());
            xlWorkBook.SaveAs(@"" + Path + "" + slas + "StuctureValidation_" + rno_ + ".xls", Excel.XlFileFormat.xlWorkbookNormal, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);

            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();


            BAL.releaseObject(xlWorkSheet);
            BAL.releaseObject(xlWorkSheet1);

            BAL.releaseObject(xlWorkBook);
            BAL.releaseObject(xlApp);

            MessageBox.Show("Data exported in " + Path + "" + slas + "StuctureValidation_" + rno_ + "");

        }
        private void Structure_Validation_Load(object sender, EventArgs e)
        {
            
            string Constr = @"Data Source=C:\DB\ETL.sdf";
            DataTable dt = null, dt1 = null;
            try
            {
                
                string query = "select * from DB";
                dt = DAL.GetData(Constr, query, "sqlce");
                cmbSource.DataSource = dt;
                cmbSource.DisplayMember = "ConName";
                cmbSource.ValueMember = "Id";
                dt1 = DAL.GetData(Constr, query, "sqlce");
                cmbTarget.DataSource = dt1;
                cmbTarget.DisplayMember = "ConName";
                cmbTarget.ValueMember = "Id";
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                Constr = string.Empty;
                dt = null;
                dt1 = null;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
