﻿namespace DataValidationTool
{
    partial class DataValidation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DataValidation));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.step1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.craeteConnectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.step2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataValidationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.structureValidationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.multipleTableToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.twoTablesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.settingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.pnlAddCon = new System.Windows.Forms.Panel();
            this.lblAdd = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblConName = new System.Windows.Forms.Label();
            this.txtConName = new System.Windows.Forms.TextBox();
            this.cmbDb = new System.Windows.Forms.ComboBox();
            this.lblDb = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.pnlAddCon.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.menuStrip1.Font = new System.Drawing.Font("Verdana", 9F);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.step1ToolStripMenuItem,
            this.step2ToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.aboutToolStripMenuItem,
            this.toolStripMenuItem1,
            this.settingToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(567, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // step1ToolStripMenuItem
            // 
            this.step1ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.craeteConnectionToolStripMenuItem});
            this.step1ToolStripMenuItem.Name = "step1ToolStripMenuItem";
            this.step1ToolStripMenuItem.Size = new System.Drawing.Size(144, 20);
            this.step1ToolStripMenuItem.Text = "Create Connections";
            // 
            // craeteConnectionToolStripMenuItem
            // 
            this.craeteConnectionToolStripMenuItem.Name = "craeteConnectionToolStripMenuItem";
            this.craeteConnectionToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.craeteConnectionToolStripMenuItem.Text = "Add Connection";
            this.craeteConnectionToolStripMenuItem.Click += new System.EventHandler(this.craeteConnectionToolStripMenuItem_Click);
            // 
            // step2ToolStripMenuItem
            // 
            this.step2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dataValidationToolStripMenuItem,
            this.structureValidationToolStripMenuItem});
            this.step2ToolStripMenuItem.Name = "step2ToolStripMenuItem";
            this.step2ToolStripMenuItem.Size = new System.Drawing.Size(141, 20);
            this.step2ToolStripMenuItem.Text = "Perform Validations";
            // 
            // dataValidationToolStripMenuItem
            // 
            this.dataValidationToolStripMenuItem.Name = "dataValidationToolStripMenuItem";
            this.dataValidationToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.dataValidationToolStripMenuItem.Text = "Data Validation";
            this.dataValidationToolStripMenuItem.Click += new System.EventHandler(this.dataValidationToolStripMenuItem_Click);
            // 
            // structureValidationToolStripMenuItem
            // 
            this.structureValidationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.multipleTableToolStripMenuItem,
            this.twoTablesToolStripMenuItem,
            this.fileToFileToolStripMenuItem});
            this.structureValidationToolStripMenuItem.Name = "structureValidationToolStripMenuItem";
            this.structureValidationToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.structureValidationToolStripMenuItem.Text = "Structure Validation";
            // 
            // multipleTableToolStripMenuItem
            // 
            this.multipleTableToolStripMenuItem.Name = "multipleTableToolStripMenuItem";
            this.multipleTableToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.multipleTableToolStripMenuItem.Text = "DB to File";
            this.multipleTableToolStripMenuItem.Click += new System.EventHandler(this.multipleTableToolStripMenuItem_Click);
            // 
            // twoTablesToolStripMenuItem
            // 
            this.twoTablesToolStripMenuItem.Name = "twoTablesToolStripMenuItem";
            this.twoTablesToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.twoTablesToolStripMenuItem.Text = "DB to DB";
            this.twoTablesToolStripMenuItem.Click += new System.EventHandler(this.twoTablesToolStripMenuItem_Click);
            // 
            // fileToFileToolStripMenuItem
            // 
            this.fileToFileToolStripMenuItem.Name = "fileToFileToolStripMenuItem";
            this.fileToFileToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.fileToFileToolStripMenuItem.Text = "File to File";
            this.fileToFileToolStripMenuItem.Click += new System.EventHandler(this.fileToFileToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.reportsToolStripMenuItem.Text = "Report";
            this.reportsToolStripMenuItem.Click += new System.EventHandler(this.reportsToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(56, 20);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 20);
            // 
            // settingToolStripMenuItem
            // 
            this.settingToolStripMenuItem.Name = "settingToolStripMenuItem";
            this.settingToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.settingToolStripMenuItem.Text = "Setting";
            this.settingToolStripMenuItem.Click += new System.EventHandler(this.settingToolStripMenuItem_Click);
            // 
            // btnExit
            // 
            this.btnExit.AutoEllipsis = true;
            this.btnExit.BackColor = System.Drawing.Color.Wheat;
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.FlatAppearance.BorderSize = 6;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExit.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.ForeColor = System.Drawing.Color.DarkRed;
            this.btnExit.Location = new System.Drawing.Point(492, 0);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnNext
            // 
            this.btnNext.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnNext.FlatAppearance.BorderColor = System.Drawing.Color.Purple;
            this.btnNext.FlatAppearance.BorderSize = 6;
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNext.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNext.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.btnNext.Location = new System.Drawing.Point(12, 297);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 23);
            this.btnNext.TabIndex = 3;
            this.btnNext.Text = "Next";
            this.btnNext.UseVisualStyleBackColor = false;
            this.btnNext.Visible = false;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // pnlAddCon
            // 
            this.pnlAddCon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.pnlAddCon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlAddCon.Controls.Add(this.lblAdd);
            this.pnlAddCon.Controls.Add(this.panel1);
            this.pnlAddCon.Location = new System.Drawing.Point(12, 37);
            this.pnlAddCon.Name = "pnlAddCon";
            this.pnlAddCon.Size = new System.Drawing.Size(544, 240);
            this.pnlAddCon.TabIndex = 4;
            this.pnlAddCon.Visible = false;
            // 
            // lblAdd
            // 
            this.lblAdd.AutoSize = true;
            this.lblAdd.Font = new System.Drawing.Font("Verdana", 10F, System.Drawing.FontStyle.Bold);
            this.lblAdd.ForeColor = System.Drawing.Color.Purple;
            this.lblAdd.Location = new System.Drawing.Point(11, 15);
            this.lblAdd.Name = "lblAdd";
            this.lblAdd.Size = new System.Drawing.Size(138, 17);
            this.lblAdd.TabIndex = 8;
            this.lblAdd.Text = "Add Connection:";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblConName);
            this.panel1.Controls.Add(this.txtConName);
            this.panel1.Controls.Add(this.cmbDb);
            this.panel1.Controls.Add(this.lblDb);
            this.panel1.Location = new System.Drawing.Point(14, 55);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(518, 131);
            this.panel1.TabIndex = 6;
            // 
            // lblConName
            // 
            this.lblConName.AutoSize = true;
            this.lblConName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConName.Location = new System.Drawing.Point(8, 21);
            this.lblConName.Name = "lblConName";
            this.lblConName.Size = new System.Drawing.Size(127, 14);
            this.lblConName.TabIndex = 0;
            this.lblConName.Text = "Connection Name:";
            // 
            // txtConName
            // 
            this.txtConName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtConName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConName.Location = new System.Drawing.Point(200, 19);
            this.txtConName.Name = "txtConName";
            this.txtConName.Size = new System.Drawing.Size(294, 22);
            this.txtConName.TabIndex = 1;
            // 
            // cmbDb
            // 
            this.cmbDb.BackColor = System.Drawing.SystemColors.Window;
            this.cmbDb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDb.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.cmbDb.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDb.FormattingEnabled = true;
            this.cmbDb.Location = new System.Drawing.Point(200, 63);
            this.cmbDb.Name = "cmbDb";
            this.cmbDb.Size = new System.Drawing.Size(294, 22);
            this.cmbDb.TabIndex = 3;
            // 
            // lblDb
            // 
            this.lblDb.AutoSize = true;
            this.lblDb.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDb.Location = new System.Drawing.Point(8, 71);
            this.lblDb.Name = "lblDb";
            this.lblDb.Size = new System.Drawing.Size(93, 14);
            this.lblDb.TabIndex = 2;
            this.lblDb.Text = "Data Source:";
            // 
            // DataValidation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.BackgroundImage = global::DataValidationTool.Properties.Resources.CAP22;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(567, 332);
            this.ControlBox = false;
            this.Controls.Add(this.pnlAddCon);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "DataValidation";
            this.Text = "One Click";
            this.Load += new System.EventHandler(this.DataValidation_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.pnlAddCon.ResumeLayout(false);
            this.pnlAddCon.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem step1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem craeteConnectionToolStripMenuItem;
      
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Panel pnlAddCon;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblConName;
        private System.Windows.Forms.TextBox txtConName;
        private System.Windows.Forms.ComboBox cmbDb;
        private System.Windows.Forms.Label lblDb;
        private System.Windows.Forms.Label lblAdd;
        private System.Windows.Forms.ToolStripMenuItem step2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dataValidationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem structureValidationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem multipleTableToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem twoTablesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem settingToolStripMenuItem;
       
    }
}