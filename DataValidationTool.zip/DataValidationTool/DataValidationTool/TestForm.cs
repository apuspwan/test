﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectionDBFactory;
using System.Data.SqlClient;
using Oracle.ManagedDataAccess.Client;

namespace DataValidationTool
{
    public partial class TestForm : Form
    {
        public TestForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ssql = "select * from productdata order by p_id asc";

            string tsql = "select * from productdata order by id asc";

            string Sconstr = "Data Source=10.74.160.123;User Id=testcoe2;Password=testcoe2;";

            string Tconstr = "Data Source=IN-AIR-MOTEST\\SQLEXPRESS;Initial Catalog=MyTest;Integrated Security=True;";



            DataTable source = DAL.GetData(Sconstr, ssql,"Oracle");

            DataTable target = DAL.GetData(Tconstr, tsql, "MS SQL Server");

            DataTable result = DataComparer(source, target);


        }

        public DataRow GetRows(string strcon,string sqlquery,string typpe)
        {
            string constr = strcon;

            var tb = new DataTable();

            if (typpe == "Server")
            {
                var con = new SqlConnection(strcon);


                var cmd = new SqlCommand();
                cmd.CommandText = sqlquery;

                cmd.Connection = con;
                con.Open();
                var adap = new SqlDataAdapter(cmd);
                adap.Fill(tb);
            }
            else if (typpe == "Oracle")
            {
                var con = new OracleConnection(strcon);

                var cmd = new OracleCommand();
                cmd.CommandText = sqlquery;

                cmd.Connection = con;
                con.Open();
                var adap = new OracleDataAdapter(cmd);
                adap.Fill(tb);
            }
            return tb.Rows[0]; 
        }
        
        public  DataTable DataComparer(DataTable S,DataTable T)
        {
            DataTable unmatched = new DataTable();
           
            for (int i = 0; i < S.Columns.Count; i++)
            {
                unmatched.Columns.Add(S.Columns[i].ToString(), typeof(string));
            }
            unmatched.Columns.Add("comment", typeof(string));
          

            DataTable Source1 = (from a in S.AsEnumerable()
                                  join b in T.AsEnumerable()
                                  on a["p_id"].ToString() equals b["id"].ToString()
                                  into g
                                  where g.Count() > 0
                                  select a).CopyToDataTable();

            DataTable Target1=(from a in T.AsEnumerable()
                                  join b in S.AsEnumerable()
                                  on a["id"].ToString() equals b["P_id"].ToString()
                                  into g
                                  where g.Count() > 0
                                  select a).CopyToDataTable();

            //DataTable dtMerged=

            unmatched = (Source1.AsEnumerable().Except(Target1.AsEnumerable(), System.Data.DataRowComparer.Default)).CopyToDataTable();

            //DataRow dr;
            //for (int i = 0; i < Source1.Rows.Count; i++)
            //{
            //    dr = unmatched.NewRow();
            //    for (int j = 0; j < Source1.Columns.Count; j++)
            //    {
            //        dr[j] = Source1.Rows[i][j].ToString();
            //    }

            //    dr["comment"] = "Src";
            //    unmatched.Rows.Add(dr);
            //}
            //for (int i = 0; i < Target1.Rows.Count; i++)
            //{
            //    dr = unmatched.NewRow();
            //    for (int j = 0; j < Target1.Columns.Count; j++)
            //    {
            //        dr[j] = Target1.Rows[i][j].ToString();
            //    }

            //    dr["comment"] = "Trg";
            //    unmatched.Rows.Add(dr);
            //}

            return unmatched;
        }
    }
}
