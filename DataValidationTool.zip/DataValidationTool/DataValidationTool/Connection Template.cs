﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectionDBFactory;
using System.Data.SqlServerCe;

namespace DataValidationTool
{
    public partial class Connection_Template : Form
    {
        string ConName = string.Empty, DbName = string.Empty, ConstrDb = string.Empty, SQL1 = string.Empty, SQL2 = string.Empty, Provider=string.Empty;
        string DSN = string.Empty, Uid = string.Empty, Password = string.Empty,ServerName=string.Empty,Port=string.Empty,Database=string.Empty;
        DataManager dbManager = null;
        string ExcelPath = string.Empty;
        public Connection_Template(string ConName, string DbName)
        {
            InitializeComponent();
           
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ConName = ConName;
            this.DbName = DbName;
        }

        private void Connection_Template_Load(object sender, EventArgs e)
        {
        
            if (DbName.Equals("SAP HANA"))
            {
                uC_Oracle1.Visible = true;
                uC_File1.Visible = false;
              
                btnTest.Enabled = true;
                uC_TeraOrac1.Visible = false;
                uC_SQL1.Visible = false;
                uC_Netezza1.Visible = false;
                lblAdd.Text = "Add Credentials for " + DbName + "";
            }
            else if (DbName.Equals("Flat File"))
            {
                uC_File1.Visible = true;
                uC_Oracle1.Visible = false;
               
                btnTest.Enabled = false;
                uC_TeraOrac1.Visible = false;
                uC_SQL1.Visible = false;
                uC_Netezza1.Visible = false;
                lblAdd.Text = "Add Path for " + DbName + "";
            }
            else if (DbName.Equals("Oracle") || DbName.Equals("Teradata"))
            {
                uC_File1.Visible = false;
                uC_Oracle1.Visible = false;
                uC_TeraOrac1.Visible = true;
                uC_Netezza1.Visible = false;
                uC_SQL1.Visible = false;
                btnTest.Enabled = true;
                lblAdd.Text = "Add Credentials for " + DbName + "";
            }
            else if (DbName.Equals("Netezza") || DbName.Equals("DB2"))
            {
                uC_File1.Visible = false;
                uC_Oracle1.Visible = false;
                uC_TeraOrac1.Visible = false;
                uC_Netezza1.Visible = true;
                btnTest.Enabled = true;
                lblAdd.Text = "Add Credentials for " + DbName + "";
            }
            else if (DbName.Equals("MS SQL Server"))
            {
                uC_File1.Visible = false;
                uC_Oracle1.Visible = false;
                uC_TeraOrac1.Visible = false;
                uC_Netezza1.Visible = false;
                uC_SQL1.Visible = true;
                btnTest.Enabled = true;
                lblAdd.Text = "Add Credentials for " + DbName + "";
            }
            else if (DbName.Equals("Excel") || DbName.Equals("Access"))
            {
               
                uC_File1.Visible = true;
                uC_Oracle1.Visible = false;
                uC_SQL1.Visible = false;
                btnTest.Enabled = false;
                uC_TeraOrac1.Visible = false;
                uC_Netezza1.Visible = false;
                btnTest.Enabled = true;
                lblAdd.Text = "Add Path for " + DbName + "";
            }
            
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
          
            if (DbName.Equals("SAP HANA"))
            {
                DSN = uC_Oracle1.DSN;
                Uid = uC_Oracle1.Uid;
                Password = uC_Oracle1.Password;
                ConstrDb = "DSN=" + DSN + ";Uid=" + Uid + ";Pwd=" + Password + ";";
                dbManager = new DataManager(DataProviderType.Odbc, ConstrDb);
            }
            else if (DbName.Equals("Oracle") || DbName.Equals("Teradata"))
            {
                DSN = uC_TeraOrac1.DbSource;
                Uid = uC_TeraOrac1.Uid;
                Password = uC_TeraOrac1.Password;
                ConstrDb = "Data Source=" + DSN + ";User Id=" + Uid + ";Password=" + Password + ";";
                if (DbName.Equals("Oracle"))
                {
                    dbManager = new DataManager(DataProviderType.Oracle, ConstrDb);
                }
                else
                {
                    dbManager = new DataManager(DataProviderType.TeraData, ConstrDb);
                }
            }
            else if (DbName.Equals("Netezza") || DbName.Equals("DB2"))
            {
                Uid = uC_Netezza1.UserId;
                Password = uC_Netezza1.Pass;
                Database = uC_Netezza1.DbName;
                ServerName = uC_Netezza1.Server;
                Port = uC_Netezza1.Port;

                ConstrDb = "Driver={NetezzaSQL};servername=" + ServerName + ";port=" + Port + ";database=" + Database + ";username=" + Uid + ";password=" + Password + ";";
                dbManager = new DataManager(DataProviderType.Odbc, ConstrDb);
            }
            else if (DbName.Equals("Excel"))
            {
                ExcelPath = uC_File1.FilePath;
                ConstrDb = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + ExcelPath + "';Extended Properties=\"Excel 12.0;ReadOnly=False;HDR=Yes;\"";
                dbManager = new DataManager(DataProviderType.Oledb, ConstrDb);
            }
            else if (DbName.Equals("MS SQL Server"))
            {
                bool check;
                check = uC_SQL1.Check;
                ServerName = uC_SQL1.MSServer;
                Database = uC_SQL1.MSDB;
                Uid = uC_SQL1.MSUID;
                Password = uC_SQL1.MSPWD;
                if (check == true)
                {
                    ConstrDb = "Data Source=" + ServerName + ";Initial Catalog=" + Database + ";Uid="+Uid+"; Password="+Password+";";
                }
                else
                {
                    ConstrDb = "Data Source=" + ServerName + ";Initial Catalog=" + Database + ";Integrated Security=True;";
                }


               
                //ConstrDb = "Data Source=" + ServerName + ";Initial Catalog=" + Database + ";Integrated Security=True;";
                dbManager = new DataManager(DataProviderType.SqlServer, ConstrDb);
            }
            else if (DbName.Equals("Access"))
            {
                ExcelPath = uC_File1.FilePath;
                ConstrDb = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + ExcelPath + "';Persist Security Info=False";
                dbManager = new DataManager(DataProviderType.Oledb, ConstrDb);
            }

            try
            {

                dbManager.Open();
                MessageBox.Show("Connected....");
            }
            catch (Exception ex)
            {
                MessageBox.Show("You are providing wrong credentials...");
            }
            finally
            {
                dbManager.Close();
                //Constr = string.Empty;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
           ConstrDb=string.Empty;
           Provider = string.Empty;
            if (DbName.Equals("Flat File"))
            {
                ConstrDb=uC_File1.FilePath;
                if (ConstrDb == string.Empty)
                {
                    MessageBox.Show("Provide file Path..");
                    return;
                }
                Provider = "Odbc";
            }
            else if (DbName.Equals("Excel"))
            {
                ConstrDb = uC_File1.FilePath;
                if (ConstrDb == string.Empty)
                {
                    MessageBox.Show("Provide file Path..");
                    return;
                }
                Provider = "Oledb";
            }
            else if (DbName.Equals("SAP HANA"))
            {
                DSN = uC_Oracle1.DSN;
                Uid = uC_Oracle1.Uid;
                Password = uC_Oracle1.Password;
                if (DSN==string.Empty|| Uid==string.Empty|| Password==string.Empty)
                {
                    MessageBox.Show("Provide Credentials..");
                    return;
                }
                ConstrDb = "DSN=" + DSN + ";Uid=" + Uid + ";Pwd=" + Password + ";";
                Provider = "Odbc";
            }
            else if (DbName.Equals("Oracle") || DbName.Equals("Teradata"))
            {
                DSN = uC_TeraOrac1.DbSource;
                Uid = uC_TeraOrac1.Uid;
                Password = uC_TeraOrac1.Password;
                if (DSN == string.Empty || Uid == string.Empty || Password == string.Empty)
                {
                    MessageBox.Show("Provide Credentials..");
                    return;
                }
                ConstrDb = "Data Source=" + DSN + ";User Id=" + Uid + ";Password=" + Password + ";";
                if (DbName.Equals("Oracle"))
                {
                    Provider = "Oracle";
                }
                else
                {
                    Provider = "Teradata";
                }
            }
            else if (DbName.Equals("Netezza") || DbName.Equals("DB2"))
            {
                Uid = uC_Netezza1.UserId;
                Password = uC_Netezza1.Pass;
                Database = uC_Netezza1.DbName;
                ServerName = uC_Netezza1.Server;
                Port = uC_Netezza1.Port;
                if (ServerName == string.Empty || Uid == string.Empty || Password == string.Empty||Database==string.Empty||Port==string.Empty)
                {
                    MessageBox.Show("Provide Credentials..");
                    return;
                }
                ConstrDb = "Driver={NetezzaSQL};servername="+ServerName+";port="+Port+";database="+Database+";username="+Uid+";password="+Password+";";
                Provider = "Odbc";
            }
            else if (DbName.Equals("MS SQL Server"))
            {

                bool check;
                check = uC_SQL1.Check;
                ServerName = uC_SQL1.MSServer;
                Database = uC_SQL1.MSDB;
                Uid = uC_SQL1.MSUID;
                Password = uC_SQL1.MSPWD;

                if (ServerName == string.Empty || Database == string.Empty)
                {
                    MessageBox.Show("Provide Credentials..");
                    return;
                }
                if (check == true)
                {
                    ConstrDb = "Data Source=" + ServerName + ";Initial Catalog=" + Database + ";Uid=" + Uid + "; Password=" + Password + ";";
                }
                else
                {
                    ConstrDb = "Data Source=" + ServerName + ";Initial Catalog=" + Database + ";Integrated Security=True;";
                }



                Provider = "MS SQL Server";
            }
            else if (DbName.Equals("Access"))
            {
                ExcelPath = uC_File1.FilePath;
                ConstrDb = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source='" + ExcelPath + "';Persist Security Info=False";
                dbManager = new DataManager(DataProviderType.Oledb, ConstrDb);
            }
            string Constr = @"Data Source=C:\DB\ETL.sdf";
           
            int i = 0;
            try
            {

                dbManager = new DataManager(DataProviderType.Sqlce, Constr);
                dbManager.Open();
              
              
                //SQL1 = "Insert into [DB$] ([id],[DB],[ConName],[ConnectionString],[Provider]) values('" + count + "','" + DbName + "','" + ConName + "','" + ConstrDb + "','" + Provider + "')";
                SQL1 = "Insert into DB (DB,ConName,ConnectionString,Provider) values('" + DbName + "','" + ConName + "','" + ConstrDb + "','" + Provider + "')";


                i = dbManager.ExecuteQuery(SQL1);
                MessageBox.Show("Credentials Saved...");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                //dbManager.Close();
                //Constr = string.Empty;
                ConstrDb = string.Empty;
                SQL1 = string.Empty;
                SQL2 = string.Empty;
                DSN = string.Empty;
                Uid = string.Empty;
                Password = string.Empty;
                ServerName = string.Empty;
                Port = string.Empty;
                Constr = string.Empty;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Dispose();
            DataValidation frs = new DataValidation();
            frs.Show();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

       

      
     
    }
}
