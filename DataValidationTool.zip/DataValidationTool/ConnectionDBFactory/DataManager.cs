﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data.SqlServerCe;
using Oracle.ManagedDataAccess.Client;
using Teradata.Client.Provider;
namespace ConnectionDBFactory
{

   public sealed class DataManager
    {
        private DbConnection dbConnection;
        private string strConnectionString;
        private DataProviderType dbProviderType;

        public DataManager(DataProviderType providerType, string
      connectionString)
        {
            this.strConnectionString = connectionString;
            this.dbProviderType = providerType;
            dbConnection = DBFactory.GetConnection(providerType);
            dbConnection.ConnectionString = connectionString;
        }
        public void Open()
        {
            if (dbConnection.State != ConnectionState.Open)
                dbConnection.Open();
        }

        public void Close()
        {
            if (dbConnection.State != ConnectionState.Closed)
                dbConnection.Close();
        }

        public DbConnection Connection
        {
            get
            {
                return dbConnection;
            }
        }

        public string ConnectionString
        {
            get
            {
                return strConnectionString;
            }
        }

        public DataProviderType DBProvider
        {
            get
            {
                return dbProviderType;
            }
        }

        public DataTable GetDataSet(string sqlString)
        {
            using (DbDataAdapter dbDataAdapter = DBFactory.GetDataAdapter(this.DBProvider))
            {
                try
                {

                    dbDataAdapter.SelectCommand = DBFactory.GetCommand(this.DBProvider);
                    dbDataAdapter.SelectCommand.CommandText = sqlString;
                    dbDataAdapter.SelectCommand.Connection = this.Connection;

                    DataTable dataTable = new DataTable();
                    dbDataAdapter.Fill(dataTable);
                    return dataTable;


                }

                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
        public DataTable GetDbReader(string sqlString, string Db)
        {
            DbDataReader dbr = DBFactory.GetDataReader(this.DBProvider);
            DbCommand cmd = DBFactory.GetCommand(this.DBProvider);
            DataTable dt = null;
            try
            {
                cmd.CommandText = sqlString;
                cmd.Connection = this.Connection;
                if (Db.Equals("Odbc"))
                {
                    dbr = cmd.ExecuteReader();
                }
                else
                {
                    dbr = cmd.ExecuteReader(CommandBehavior.KeyInfo);
                }
                dt = dbr.GetSchemaTable();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                dbr.Close();
            }
            return dt;


        }

        public DataTable GetDataReader(string sql,DataTable dt)
        {
            DataTable dtNew = dt.Clone();
            DbDataReader dbr = DBFactory.GetDataReader(this.DBProvider);
            DbCommand cmd = DBFactory.GetCommand(this.DBProvider);
            DataRow drRow;
            try
            {
                cmd.CommandText = sql;
                cmd.Connection = this.Connection;
             
                dbr = cmd.ExecuteReader();
                while (dbr.Read())
                {
                    drRow = dtNew.NewRow();
                    for (int i = 0; i < dt.Columns.Count-1; i++)
                    {
                        drRow[((DataColumn)dtNew.Columns[i + 1])] = dbr[i];
                    }
                    dtNew.Rows.Add(drRow);
                }
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
                dbr.Close();
            }
            return dtNew;


        }
        public int ExecuteQuery(string SQL)
        {
            int i = 0;
            DbCommand cmd = DBFactory.GetCommand(this.DBProvider);
            try
            {
                cmd.CommandText = SQL;
                cmd.Connection = this.Connection;
                i = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
            }
            return i;
        }
        public  int RowCount(string SQL)
        {
            int count = 0;
            DbCommand cmd = DBFactory.GetCommand(this.DBProvider);
            try
            {
                cmd.CommandText = SQL;
                cmd.Connection = this.Connection;
                count =(int) cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                cmd.Dispose();
            }
            return count;
        }
    }
}
