﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data.SqlServerCe;
using Oracle.ManagedDataAccess.Client;
using Microsoft.VisualBasic.FileIO;

namespace ConnectionDBFactory
{
   public class BAL
    {
           
       //This function only work for Primary key.....
       public static DataTable DataComapePrimaryKey(DataTable dtSource, DataTable dtTarget)
       {
           DataTable sourceNew = null, targetNew = null,sourceUn=null,targetUn=null;
           DataTable final=new DataTable();
           DataRow dr;
           for (int i = 0; i < dtSource.Columns.Count; i++)
           {

               final.Columns.Add(dtSource.Columns[i].ToString(), typeof(string));
           }
           final.Columns.Add("Comment", typeof(string));
           try
           {
               var var1=  dtSource.AsEnumerable().Except(dtTarget.AsEnumerable(),System.Data.DataRowComparer.Default);
               var var2 = dtTarget.AsEnumerable().Except(dtSource.AsEnumerable(), System.Data.DataRowComparer.Default);

               var vSourceNew = from a in var1
                                join b in var2
                                on a[0].ToString() equals b[0].ToString()
                                into g
                                where g.Count() == 0
                                select a;

               if (vSourceNew.Any())
               {
                   sourceNew = vSourceNew.CopyToDataTable();
                   for (int i = 0; i < sourceNew.Rows.Count; i++)
                   {
                       dr = final.NewRow();
                       for (int j = 0; j < sourceNew.Columns.Count; j++)
                       {
                           dr[j] = Convert.ToString(sourceNew.Rows[i][j]);
                       }
                       dr["Comment"] = "new in src";
                       final.Rows.Add(dr);
                   }
                   sourceNew = null;
               }
               var vTargetNew = from a in var2
                               join b in var1
                                on a[0].ToString() equals b[0].ToString()
                                into g
                                where g.Count() == 0
                                select a;
               if (vTargetNew.Any())
               {
                   targetNew = vTargetNew.CopyToDataTable();
                   for (int i = 0; i < targetNew.Rows.Count; i++)
                   {
                       dr = final.NewRow();
                       for (int j = 0; j < targetNew.Columns.Count; j++)
                       {
                           dr[j] = Convert.ToString(targetNew.Rows[i][j]);
                       }
                       dr["Comment"] = "new in trg";
                       final.Rows.Add(dr);
                    }
                   targetNew = null;
               }


               var vsourceUn = from a in var1
                               join b in var2
                               on a[0].ToString() equals b[0].ToString()
                               orderby a[0] ascending
                               select a;


               var vtargetUn = from a in var2
                               join b in var1
                               on a[0].ToString() equals b[0].ToString()
                               orderby a[0] ascending
                               select a;

               if (vsourceUn.Any())
               {
                   sourceUn = vsourceUn.CopyToDataTable();
                   targetUn = vtargetUn.CopyToDataTable();
                   for (int i = 0; i < sourceUn.Rows.Count; i++)
                   {
                       dr = final.NewRow();
                       for (int j = 0; j < sourceUn.Columns.Count; j++)
                       {
                           dr[j] = Convert.ToString(sourceUn.Rows[i][j]);
                       }
                       dr["Comment"] = "src";
                       final.Rows.Add(dr);
                   }
                   sourceUn = null;

                   for (int k = 0; k < targetUn.Rows.Count; k++)
                   {

                       dr = final.NewRow();
                       for (int l = 0; l < targetUn.Columns.Count; l++)
                       {
                           dr[l] = Convert.ToString(targetUn.Rows[k][l].ToString());
                       }
                       dr["Comment"] = "trg";
                       final.Rows.Add(dr);

                   }
                   targetUn = null;
               }
             

           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               dtSource = null;
               dtTarget = null;
               sourceNew = null;
               targetNew = null;
               sourceUn = null;
               targetUn = null;
           }
           return final;
       }
       
  //End function.....

       public static int GreaterRows(int T1, int T2)
       {
           int count = 0;
           if (T1 > T2)
           {
               count = T1;
           }
           else if (T2 > T1)
           {
               count = T2;
           }

           return count;

       }

        public static DataTable GetDataTabletFromCSVFile(string csv_file_path, string Delimiter)
        {

            DataTable csvData = new DataTable();

            try
            {
                using (TextFieldParser csvReader = new TextFieldParser(csv_file_path))
                {
                    csvReader.SetDelimiters(new string[] { Delimiter });
                    csvReader.HasFieldsEnclosedInQuotes = true;
                    //read column names
                    string[] colFields = csvReader.ReadFields();
                    foreach (string column in colFields)
                    {
                        DataColumn datecolumn = new DataColumn(column);
                        datecolumn.AllowDBNull = true;
                        csvData.Columns.Add(datecolumn);
                    }
                    while (!csvReader.EndOfData)
                    {
                        string[] fieldData = csvReader.ReadFields();
                        //Making empty value as null
                        for (int i = 0; i < fieldData.Length; i++)
                        {
                            if (fieldData[i] == "")
                            {
                                fieldData[i] = null;
                            }
                        }
                        csvData.Rows.Add(fieldData);
                    }
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return csvData;
        }

        //public static DataTable GetSchemaMatch(DataTable dtSource, DataTable dtTarget)
        //{
        //    DataTable dt = dtSource.Clone();
        //    DataRow dr;
        //    try
        //    {
        //        if (dtSource.Rows.Count > dtTarget.Rows.Count)
        //        {

        //            for (int i = 0; i < dtSource.Rows.Count; i++)
        //            {
        //                dr = dt.NewRow();
        //                for (int j = 0; j < dtSource.Columns.Count; j++)
        //                {
        //                    dr[j] = dtSource.Rows[i][j].ToString();
        //                }

        //                dt.Rows.Add(dr);

        //                for (int k = 0; k < dtTarget.Rows.Count; k++)
        //                {
        //                    if (i == k)
        //                    {
        //                        dr = dt.NewRow();
        //                        for (int l = 0; l < dtTarget.Columns.Count; l++)
        //                        {
        //                            dr[l] = dtTarget.Rows[k][l].ToString();
        //                        }

        //                        dt.Rows.Add(dr);
        //                    }
        //                    else if (i != k)
        //                    {
        //                        continue;
        //                    }
        //                }
        //            }
        //        }
        //        else if (dtTarget.Rows.Count > dtSource.Rows.Count)
        //        {
        //            for (int i = 0; i < dtTarget.Rows.Count; i++)
        //            {
        //                dr = dt.NewRow();
        //                for (int j = 0; j < dtTarget.Columns.Count; j++)
        //                {
        //                    dr[j] = dtTarget.Rows[i][j].ToString();
        //                }

        //                dt.Rows.Add(dr);

        //                for (int k = 0; k < dtSource.Rows.Count; k++)
        //                {
        //                    if (i == k)
        //                    {
        //                        dr = dt.NewRow();
        //                        for (int l = 0; l < dtSource.Columns.Count; l++)
        //                        {
        //                            dr[l] = dtSource.Rows[k][l].ToString();
        //                        }

        //                        dt.Rows.Add(dr);
        //                    }
        //                    else if (i != k)
        //                    {
        //                        continue;
        //                    }
        //                }
        //            }
        //        }
        //        else if (dtTarget.Rows.Count == dtSource.Rows.Count)
        //        {
        //            for (int i = 0; i < dtSource.Rows.Count; i++)
        //            {
        //                dr = dt.NewRow();
        //                for (int j = 0; j < dtSource.Columns.Count; j++)
        //                {
        //                    dr[j] = dtSource.Rows[i][j].ToString();
        //                }

        //                dt.Rows.Add(dr);

        //                for (int k = 0; k < dtTarget.Rows.Count; k++)
        //                {
        //                    if (i == k)
        //                    {
        //                        dr = dt.NewRow();
        //                        for (int l = 0; l < dtTarget.Columns.Count; l++)
        //                        {
        //                            dr[l] = dtTarget.Rows[k][l].ToString();
        //                        }

        //                        dt.Rows.Add(dr);
        //                    }
        //                    else if (i != k)
        //                    {
        //                        continue;
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    finally
        //    {
        //        dtSource = null;
        //        dtTarget = null;
        //    }
        //    return dt;
        //}
        public static void releaseObject(object obj)
        {
            try
            {

                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                throw ex;
            }
            finally
            {
                GC.Collect();
            }
        }

     
       //For random number


       //code to pull data from database and generate auto id into new table..
       //
       //

      


       //end of code..


        public static string tblName(string sql)
        {
            string tablename = string.Empty;
                      
            //string substring = string.Empty;
            try
            {
                int index = sql.IndexOf("FROM", StringComparison.CurrentCultureIgnoreCase);

                tablename = sql.Substring(index + 5);

                if (tablename.Contains(' '))
                {
                    int space = tablename.IndexOf(' ');
                    tablename = tablename.Substring(0, space);
                }
              
              
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
              
            }
            return tablename;
        }
        public static string GetQuery(string Sql)
        {
            string tablename = string.Empty;
            string finaltable = string.Empty;
            string result = string.Empty;
        
            tablename = tblName(Sql);
            finaltable = tablename + ".csv";
            result = Sql.Replace(tablename, finaltable);

            return result;
        }
      public  class UniqueRandom
        {
            private readonly List<int> _currentList;
            private readonly Random _random = new Random();

            public UniqueRandom(IEnumerable<int> seed)
            {
                _currentList = new List<int>(seed);
            }

            public int Next()
            {
                if (_currentList.Count == 0)
                {
                    throw new ApplicationException("No more numbers");
                }

                int i = _random.Next(_currentList.Count);
                int result = _currentList[i];
                _currentList.RemoveAt(i);
                return result;
            }
        }
       //
    }
}
