﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ConnectionDBFactory
{
   public class DAL
    {
       

       public static DataTable GetData(string ConStr, string SQL, string Db)
       {
           DataTable dt = null;
           DataManager dbManager = null; 
           try
           {
               if (Db.Equals("Odbc"))
               {
                   dbManager = new DataManager(DataProviderType.Odbc, ConStr);
                   dbManager.Open();
                   

               }
               else if (Db.Equals("Teradata"))
               {
                   dbManager = new DataManager(DataProviderType.TeraData, ConStr);
                   dbManager.Open();
               }
               else if (Db.Equals("Oracle"))
               {
                   dbManager = new DataManager(DataProviderType.Oracle, ConStr);
                   dbManager.Open();

               }
               else if (Db.Equals("Oledb"))
               {
                   dbManager = new DataManager(DataProviderType.Oledb, ConStr);
                   dbManager.Open();

               }
               else if (Db.Equals("MS SQL Server"))
               {
                   dbManager = new DataManager(DataProviderType.SqlServer, ConStr);
                   dbManager.Open();

               }
               else if (Db.Equals("sqlce"))
               {
                   dbManager = new DataManager(DataProviderType.Sqlce, ConStr);
                   dbManager.Open();

               }
               dt = dbManager.GetDataSet(SQL);

           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               dbManager.Close();
           }
           return dt;
       }
      

       public static string[] GetConStr(string Id)
       {
           DataTable dt = null;
           DataManager dbManager = null;
           string DbConstr = string.Empty;
           string Provider = string.Empty;
           string DB = string.Empty;
           string[] Result = new string[3];
           string Constr = @"Data Source=C:\DB\ETL.sdf";
           string sql = "select ConnectionString,Provider,DB from DB where Id='" + Id + "'";
           try
           {
               
               dbManager = new DataManager(DataProviderType.Sqlce, Constr);
               dbManager.Open();
               dt = dbManager.GetDataSet(sql);
               DbConstr = dt.Rows[0]["ConnectionString"].ToString(); 
               Provider = dt.Rows[0]["Provider"].ToString();
               DB=dt.Rows[0]["DB"].ToString();
               Result[0] = DbConstr;
               Result[1] = Provider;
               Result[2] = DB;
             
           }
               
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               dbManager.Close();
               DbConstr = string.Empty;
               Provider = string.Empty;
               DB = string.Empty;
               Constr = string.Empty;
               sql = string.Empty;
              
           }
           return Result;
       }

       public static DataTable GetDataStruture(string ConStr, string TblName, string Db, string tbl)
       {

           DataTable SchemaTable = null, dt = null;
           DataManager dbManager = null;


           try
           {
               if (Db.Equals("Odbc"))
               {
                   dbManager = new DataManager(DataProviderType.Odbc, ConStr);
                   dbManager.Open();
                  
               }
               else if (Db.Equals("Teradata"))
               {
                   dbManager = new DataManager(DataProviderType.TeraData, ConStr);
                   dbManager.Open();
               }
               else if (Db.Equals("Oracle"))
               {
                   dbManager = new DataManager(DataProviderType.Oracle, ConStr);
                   dbManager.Open();
                 

               }
               else if (Db.Equals("Oledb"))
               {
                   dbManager = new DataManager(DataProviderType.Oledb, ConStr);
                   dbManager.Open();

               }
               else if (Db.Equals("MS SQL Server"))
               {
                   dbManager = new DataManager(DataProviderType.SqlServer, ConStr);
                   dbManager.Open();

               }
               string sql = "select * from " + TblName + "";
               SchemaTable = dbManager.GetDbReader(sql, Db);
               dt = GetSchemaData(SchemaTable, tbl);
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               dbManager.Close();

           }
           return dt;
       }


       //For Comapiring DataValidation Module only need to create a generic code for both..


       public static DataTable GetDataStrutureForDataValidation(string ConStr,  string Db, string SQL)
       {

           DataTable SchemaTable = null;
           DataManager dbManager = null;


           try
           {
               if (Db.Equals("Odbc"))
               {
                   dbManager = new DataManager(DataProviderType.Odbc, ConStr);
                   dbManager.Open();

               }
               else if (Db.Equals("Teradata"))
               {
                   dbManager = new DataManager(DataProviderType.TeraData, ConStr);
                   dbManager.Open();
               }
               else if (Db.Equals("Oracle"))
               {
                   dbManager = new DataManager(DataProviderType.Oracle, ConStr);
                   dbManager.Open();


               }
               else if (Db.Equals("Oledb"))
               {
                   dbManager = new DataManager(DataProviderType.Oledb, ConStr);
                   dbManager.Open();

               }
               else if (Db.Equals("MS SQL Server"))
               {
                   dbManager = new DataManager(DataProviderType.SqlServer, ConStr);
                   dbManager.Open();

               }
            
               SchemaTable = dbManager.GetDbReader(SQL, Db);

           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               dbManager.Close();

           }
           return SchemaTable;
       }

       public static DataTable GetDataWithAutoId(string ConStr,string Db,string SQL)
       {
           DataTable dt = null;
           DataTable dtNew = new DataTable();
           DataColumn auto = new DataColumn("AutoID", typeof(System.Int32));
           dtNew.Columns.Add(auto);
           auto.AutoIncrement = true;

           auto.AutoIncrementSeed = 1;
           auto.AutoIncrementStep = 1;
           auto.ReadOnly = true;

           dt = GetDataStrutureForDataValidation(ConStr, Db, SQL);
           for (int i = 0; i < dt.Rows.Count; i++)
           {

               dtNew.Columns.Add(dt.Rows[i][0].ToString(), typeof(string));
           }
           DataManager dbManager = null;
           try
           {
               if (Db.Equals("Odbc"))
               {
                   dbManager = new DataManager(DataProviderType.Odbc, ConStr);
                   dbManager.Open();



               }
               else if (Db.Equals("Teradata"))
               {
                   dbManager = new DataManager(DataProviderType.TeraData, ConStr);
                   dbManager.Open();
               }
               else if (Db.Equals("Oracle"))
               {
                   dbManager = new DataManager(DataProviderType.Oracle, ConStr);
                   dbManager.Open();
                   

               }
               else if (Db.Equals("Oledb"))
               {
                   dbManager = new DataManager(DataProviderType.Oledb, ConStr);
                   dbManager.Open();

               }
               else if (Db.Equals("MS SQL Server"))
               {
                   dbManager = new DataManager(DataProviderType.SqlServer, ConStr);
                   dbManager.Open();

               }
               dtNew = dbManager.GetDataReader(SQL, dtNew);
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               dbManager.Close();
               dt = null;
           }
           return dtNew;
       }
       public static void InsertReport(DateTime date, string sourceDb, string Targetdb, string ValidType, int SourCount, int TargCount, int NewSorc, int NewTarg, int Unmatch)
       {
           DataManager dbManager = null;
           string SQL = string.Empty;
           string Constr = @"Data Source=C:\DB\ETL.sdf";
           int i = 0;
           try
           {
               dbManager = new DataManager(DataProviderType.Sqlce, Constr);
               dbManager.Open();



               SQL = "Insert into Report (Date,SourceDb,TargetDb,ValidationType,SourceCount,TargetCount,NewSource,NewTarget,UnMatched) values('" + date + "','" + sourceDb + "','" + Targetdb + "','" + ValidType + "','" + SourCount + "','" + TargCount + "','" + NewSorc + "','" + NewTarg + "','" + Unmatch + "')";
               i = dbManager.ExecuteQuery(SQL);
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               dbManager.Close();
           }
       }
       public static int dtRowCount(string ConStr,string sql,string Db)
       {
           int count = 0;
           DataManager dbManager = null;
           try
           {
               if (Db.Equals("Odbc"))
               {
                   dbManager = new DataManager(DataProviderType.Odbc, ConStr);
                   dbManager.Open();

                  
               }
               else if (Db.Equals("Teradata"))
               {
                   dbManager = new DataManager(DataProviderType.TeraData, ConStr);
                   dbManager.Open();
               }
                   
               else if (Db.Equals("Oracle"))
               {
                   dbManager = new DataManager(DataProviderType.Oracle, ConStr);
                   dbManager.Open();
                
               }
               else if (Db.Equals("Oledb"))
               {
                   dbManager = new DataManager(DataProviderType.Oledb, ConStr);
                   dbManager.Open();
                  
               }
               else if (Db.Equals("MS SQL Server"))
               {
                   dbManager = new DataManager(DataProviderType.SqlServer, ConStr);
                   dbManager.Open();
                
               }
               else if (Db.Equals("sqlce"))
               {
                   dbManager = new DataManager(DataProviderType.Sqlce, ConStr);
                   dbManager.Open();
                  
               }
               count = dbManager.RowCount(sql);

           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               dbManager.Close();
           }
           return count;
       }
       private static DataTable GetSchemaData(DataTable dt1, string tbl)
       {

           DataTable dt = new DataTable();
           dt.Columns.Add("TableName", typeof(string));
           dt.Columns.Add("ColumnName", typeof(string));
           dt.Columns.Add("ColumnSize", typeof(string));
           dt.Columns.Add("IsUnique", typeof(string));
           dt.Columns.Add("IsKey", typeof(string));
           dt.Columns.Add("DataType", typeof(string));
           dt.Columns.Add("AllowNull", typeof(string));
           for (int i = 0; i < dt1.Rows.Count; i++)
           {

               DataRow dr = dt.NewRow();
               dr["TableName"] = tbl;
               dr["ColumnName"] = dt1.Rows[i]["ColumnName"].ToString();

               dr["ColumnSize"] = dt1.Rows[i]["ColumnSize"].ToString();

               dr["IsUnique"] = dt1.Rows[i]["IsUnique"].ToString();
               dr["IsKey"] = dt1.Rows[i]["IsKey"].ToString();
               dr["DataType"] = dt1.Rows[i]["DataType"].ToString();
               dr["AllowNull"] = dt1.Rows[i]["AllowDBNull"].ToString();
               dt.Rows.Add(dr);

           }

           return dt;
       }

       
     
    }
}
