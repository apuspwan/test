﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Common;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Data.SqlServerCe;
using Oracle.ManagedDataAccess.Client;
using Teradata.Client.Provider;
namespace ConnectionDBFactory
{
    public enum DataProviderType
    {
        Oracle,
        SqlServer,
        Sqlce,
        Odbc,
        Oledb,
        TeraData
    }
   public class DBFactory
    {
        public static DbProviderFactory objFactory = null;
        public static DbProviderFactory GetDataProvider(DataProviderType provider)
        {
            switch (provider)
            {
                case DataProviderType.Oracle:
                    objFactory = OracleClientFactory.Instance;
                    break;
                case DataProviderType.SqlServer:
                    objFactory = SqlClientFactory.Instance;
                    break;
                case DataProviderType.Odbc:
                    objFactory = OdbcFactory.Instance;
                    break;
                case DataProviderType.Oledb:
                    objFactory = OleDbFactory.Instance;
                    break;
                case DataProviderType.Sqlce:
                    objFactory = SqlClientFactory.Instance;
                    break;
                case DataProviderType.TeraData:
                    objFactory = TdFactory.Instance;
                    break;
                    
                    
            }
            return objFactory;
        }

        public static DbConnection GetConnection(DataProviderType providerType)
        {
            switch (providerType)
            {
                case DataProviderType.Oracle:
                    return new OracleConnection();
                case DataProviderType.SqlServer:
                    return new SqlConnection();
                case DataProviderType.Odbc:
                    return new OdbcConnection();
                case DataProviderType.Oledb:
                    return new OleDbConnection();
                case DataProviderType.Sqlce:
                    return new SqlCeConnection();
                case DataProviderType.TeraData:
                    return new TdConnection();
                default:
                    return null;
                   
            }
        }
        public static DbCommand GetCommand(DataProviderType providerType)
        {
            switch (providerType)
            {
                    
                case DataProviderType.Oracle:
                    return new OracleCommand();
                case DataProviderType.SqlServer:
                    return new SqlCommand();
                case DataProviderType.Odbc:
                    return new OdbcCommand();
                case DataProviderType.Oledb:
                    return new OleDbCommand();
                case DataProviderType.Sqlce:
                    return new SqlCeCommand();
                case DataProviderType.TeraData:
                    return new TdCommand();
                default:
                    return null;
            }
        }

        public static DbDataAdapter GetDataAdapter(DataProviderType providerType)
        {
            switch (providerType)
            {
                case DataProviderType.Oracle:
                    return new OracleDataAdapter();
                case DataProviderType.SqlServer:
                    return new SqlDataAdapter();
                case DataProviderType.Odbc:
                    return new OdbcDataAdapter();
                case DataProviderType.Oledb:
                    return new OleDbDataAdapter();
                case DataProviderType.Sqlce:
                    return new SqlCeDataAdapter();
                case DataProviderType.TeraData:
                    return new TdDataAdapter();
                default:
                    return null;
            }
        }
        public static DbDataReader GetDataReader(DataProviderType providerType)
        {
            OracleDataReader odr = null;
            SqlDataReader sdr = null;
            OdbcDataReader oddr = null;
            OleDbDataReader oldr = null;
            SqlCeDataReader ocedr = null;
            TdDataReader oTdr = null;
            switch (providerType)
            {
                case DataProviderType.Oracle:
                    return odr;
                case DataProviderType.SqlServer:
                    return sdr;
                case DataProviderType.Odbc:
                    return oddr;
                case DataProviderType.Oledb:
                    return oldr;
                case DataProviderType.Sqlce:
                    return ocedr;
                case DataProviderType.TeraData:
                    return oTdr;
                default:
                    return null;
            }
        }

    }
}
